#include "targets.h"
#include "options.h"
#include "logging.h"

// Define helper macros if not already defined
#ifndef QUOTE
#define QUOTE(arg) #arg
#endif
#ifndef STR
#define STR(macro) QUOTE(macro)
#endif

// Target Name
#ifdef TARGET_NAME
const unsigned char target_name[] = "\xBE\xEF\xCA\xFE" STR(TARGET_NAME);
#else
const unsigned char target_name[] = "\xBE\xEF\xCA\xFE" "STM32_DIY_TX";
#endif
const uint8_t target_name_size = sizeof(target_name);

// Commit Hash
#ifdef LATEST_COMMIT
const char commit[] = {LATEST_COMMIT, 0};
#else
const char commit[] = "000000";
#endif

// Version
#if defined(UNIT_TEST)
const char version[] = "1.2.3";
#elif defined(LATEST_VERSION)
const char version[] = {LATEST_VERSION, 0};
#else
const char version[] = "0.0.0";
#endif

// WiFi Defaults (Not used on STM32 but required for compilation linking)
#if defined(TARGET_TX)
const char *wifi_hostname = "elrs_tx";
const char *wifi_ap_ssid = "ExpressLRS TX";
#else
const char *wifi_hostname = "elrs_rx";
const char *wifi_ap_ssid = "ExpressLRS RX";
#endif
const char *wifi_ap_password = "expresslrs";
const char *wifi_ap_address = "10.0.0.1";

// Global Variables
char product_name[ELRSOPTS_PRODUCTNAME_SIZE+1];
char device_name[ELRSOPTS_DEVICENAME_SIZE+1];
uint32_t logo_image;
firmware_options_t firmwareOptions;

// External hardware init function (STM32 version takes no args now)
#if defined(PLATFORM_ESP32) || defined(PLATFORM_ESP8266)
extern bool hardware_init(EspFlashStream &strmFlash);
#else
extern bool hardware_init();
#endif

// Initialize Options
bool options_init()
{
    // Initialize Logger
    // debugCreateInitLogger(); // Logger usually needs Serial init first, which we do in main.cpp

    // Set Default Device Names
    strcpy(product_name, "DIY STM32 TX");
    strcpy(device_name, "STM32 TX");

    // Initialize Firmware Options with safe defaults
    memset(&firmwareOptions, 0, sizeof(firmwareOptions));

    // UID Loading (From Binding Phrase)
    // Note: The Binding Phrase logic usually injects UID via the build system into a separate file.
    // If MY_UID is defined in common.h or targets.h via platformio.ini:
    #ifdef MY_UID
    const uint8_t uid_bytes[] = MY_UID;
    memcpy(firmwareOptions.uid, uid_bytes, sizeof(firmwareOptions.uid));
    firmwareOptions.hasUID = true;
    #else
    // Fallback if UID macros are missing (Manual binding phrase entry is safer via platformio.ini -D MY_BINDING_PHRASE)
    firmwareOptions.hasUID = false; 
    #endif

    firmwareOptions.domain = 0; // Default domain
    
    #if defined(TARGET_TX)
        firmwareOptions.tlm_report_interval = 240U; // Default TLM interval
        firmwareOptions.fan_min_runtime = 30U;
        firmwareOptions.unlock_higher_power = true; // Unlock high power for DIY
        firmwareOptions.is_airport = false;
        firmwareOptions.uart_baud = 420000;
    #endif

    // Initialize Hardware (Pins)
    // For STM32, this calls the stripped-down hardware.cpp we made earlier
    #if defined(PLATFORM_ESP32) || defined(PLATFORM_ESP8266)
        // This path is unreachable in this STM32 build config
        return false; 
    #else
        return hardware_init();
    #endif
}