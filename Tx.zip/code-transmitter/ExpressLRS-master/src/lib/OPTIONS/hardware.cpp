#include "options.h"
#include "helpers.h"
#include "targets.h" // Ensures macros like GPIO_PIN_NSS are visible

#if !defined(UNIT_TEST)

// Dummy function to satisfy linker - we don't use FlashStream on STM32 here
bool hardware_init()
{
    return true;
}

// Map the dynamic field names to the static macros defined in platformio.ini
int hardware_pin(nameType name)
{
    switch(name) {
        // --- Radio Pins ---
        case HARDWARE_radio_nss: return GPIO_PIN_NSS;
        case HARDWARE_radio_dio1: return GPIO_PIN_DIO1;
        case HARDWARE_radio_busy: return GPIO_PIN_BUSY;
        case HARDWARE_radio_rst: return GPIO_PIN_RST;
        case HARDWARE_radio_sck: return GPIO_PIN_SCK;
        case HARDWARE_radio_miso: return GPIO_PIN_MISO;
        case HARDWARE_radio_mosi: return GPIO_PIN_MOSI;

        // --- Serial (CRSF) Pins ---
        case HARDWARE_serial_rx: return GPIO_PIN_RCSIGNAL_RX;
        case HARDWARE_serial_tx: return GPIO_PIN_RCSIGNAL_TX;

        // --- LED ---
        case HARDWARE_led: return GPIO_PIN_LED;
        
        // --- Buttons (If unused, they return UNDEF_PIN) ---
        case HARDWARE_button: return GPIO_PIN_BUTTON;
        case HARDWARE_button2: return GPIO_PIN_BUTTON2;

        // --- Vbat ---
        case HARDWARE_vbat: return GPIO_ANALOG_VBAT;

        // --- Defaults for anything else ---
        default: return UNDEF_PIN;
    }
}

bool hardware_flag(nameType name)
{
    switch(name) {
        // Example: If you inverted LED logic in platformio.ini
        #ifdef GPIO_LED_INVERTED
        case HARDWARE_led_red_invert: return true; 
        #endif
        default: return false;
    }
}

int hardware_int(nameType name)
{
    switch(name) {
        case HARDWARE_vbat_scale: return ANALOG_VBAT_SCALE;
        case HARDWARE_vbat_offset: return ANALOG_VBAT_OFFSET;
        default: return 0;
    }
}

float hardware_float(nameType name)
{
    return 0.0f;
}

const int16_t* hardware_i16_array(nameType name)
{
    return nullptr;
}

const uint16_t* hardware_u16_array(nameType name)
{
    return nullptr;
}

#endif