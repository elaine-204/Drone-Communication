#pragma once

#include "device.h"

// --- FIX: Dummy Definitions for STM32 ---
#ifndef GPIO_PIN_LED_RED
    #define GPIO_PIN_LED_RED UNDEF_PIN
#endif
#ifndef GPIO_PIN_LED_GREEN
    #define GPIO_PIN_LED_GREEN UNDEF_PIN
#endif
#ifndef GPIO_PIN_LED_BLUE
    #define GPIO_PIN_LED_BLUE UNDEF_PIN
#endif

#ifndef GPIO_LED_RED_INVERTED
    #define GPIO_LED_RED_INVERTED false
#endif
#ifndef GPIO_LED_GREEN_INVERTED
    #define GPIO_LED_GREEN_INVERTED false
#endif
#ifndef GPIO_LED_BLUE_INVERTED
    #define GPIO_LED_BLUE_INVERTED false
#endif
// ----------------------------------------

extern device_t LED_device;