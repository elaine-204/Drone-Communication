#include "targets.h"
#include "common.h"
#include "devLED.h"

constexpr uint8_t LEDSEQ_RADIO_FAILED[] = { 20, 100 }; // 200ms on, 1000ms off
constexpr uint8_t LEDSEQ_DISCONNECTED[] = { 50, 50 };  // 500ms on, 500ms off
constexpr uint8_t LEDSEQ_BINDING[] = { 10, 10, 10, 100 };   // 2x 100ms blink, 1s pause
constexpr uint8_t LEDSEQ_MODEL_MISMATCH[] = { 10, 10, 10, 10, 10, 100 };   // 3x 100ms blink, 1s pause
constexpr uint8_t LEDSEQ_UPDATE[] = { 20, 5, 5, 5, 5, 40 };   // 200ms on, 2x 50ms off/on, 400ms off

static const uint8_t *_durations;
static uint8_t _count;
static uint8_t _counter = 0;
static bool _inverted = false;

// Helper to determine inversion (active low vs active high)
static bool isLedInverted() {
    #ifdef GPIO_LED_INVERTED
        return true;
    #else
        return false;
    #endif
}

static uint16_t updateLED()
{
    if (GPIO_PIN_LED == UNDEF_PIN) return DURATION_NEVER;

    bool on = (_counter % 2 == 0); // Even index = ON duration
    bool pinState = on ? (HIGH ^ _inverted) : (LOW ^ _inverted);
    
    digitalWrite(GPIO_PIN_LED, pinState);

    if (++_counter >= _count) {
        _counter = 0;
    }
    return _durations[_counter] * 10;
}

static uint16_t flashLED(const uint8_t durations[], uint8_t count)
{
    _counter = 0;
    _durations = durations;
    _count = count;
    return updateLED();
}

static bool initialize()
{
    if (GPIO_PIN_LED != UNDEF_PIN)
    {
        pinMode(GPIO_PIN_LED, OUTPUT);
        _inverted = isLedInverted();
        digitalWrite(GPIO_PIN_LED, LOW ^ _inverted); // Default Off
        return true;
    }
    return false;
}

static int timeout()
{
    return updateLED();
}

static int event()
{
    switch (connectionState)
    {
    case connected:
        // Solid ON for connected
        if (GPIO_PIN_LED != UNDEF_PIN) digitalWrite(GPIO_PIN_LED, HIGH ^ _inverted);
        return DURATION_NEVER;
        
    case disconnected:
        return flashLED(LEDSEQ_DISCONNECTED, sizeof(LEDSEQ_DISCONNECTED));
        
    case radioFailed:
    case noCrossfire:
        return flashLED(LEDSEQ_RADIO_FAILED, sizeof(LEDSEQ_RADIO_FAILED));
        
        
    case tentative: // Model match mismatch usually
         return flashLED(LEDSEQ_MODEL_MISMATCH, sizeof(LEDSEQ_MODEL_MISMATCH));

    default:
        return DURATION_NEVER;
    }
}

static int start()
{
    return event();
}

device_t LED_device = {
    .initialize = initialize,
    .start = start,
    .event = event,
    .timeout = timeout,
    .subscribe = EVENT_CONNECTION_CHANGED | EVENT_ENTER_BIND_MODE | EVENT_EXIT_BIND_MODE
};
