#if defined(TARGET_TX)
#include "CRSFHandset.h"
#include "handset.h"
#include "CRSFEndpoint.h"
#include "CRSFRouter.h"
#include "FIFO.h"
#include "helpers.h"
#include "logging.h"
#include "options.h"
#include "targets.h"

// Define the Port for STM32. 
// Note: You must ensure 'Serial1' (or whichever serial corresponds to your pinned JR bay) is correct for your variant.
// Common for STM32F411 Blackpills is Serial1 on PA9/PA10.
HardwareSerial & CRSFHandset::Port = Serial1;

static constexpr int HANDSET_TELEMETRY_FIFO_SIZE = 128; 

/// Out FIFO to buffer messages///
static constexpr auto CRSF_SERIAL_OUT_FIFO_SIZE = 256U;
static FIFO<CRSF_SERIAL_OUT_FIFO_SIZE> SerialOutFIFO;

Stream *CRSFHandset::PortSecondary;

/// UART Handling ///
uint32_t CRSFHandset::GoodPktsCountResult = 0;
uint32_t CRSFHandset::BadPktsCountResult = 0;

bool CRSFHandset::halfDuplex = false;

/// OpenTX mixer sync ///
static constexpr int32_t OpenTXsyncPacketInterval = 200; // in ms
static constexpr int32_t OpenTXsyncOffsetSafeMargin = 1000; // 100us

/// UART Handling ///
static const int32_t TxToHandsetBauds[] = {400000, 115200, 5250000, 3750000, 1870000, 921600, 2250000};
uint8_t CRSFHandset::UARTcurrentBaudIdx = 6;   
uint32_t CRSFHandset::UARTrequestedBaud = 5250000;

// for the UART wdt, every 1000ms we change bauds when connect is lost
static constexpr int UARTwdtInterval = 1000;

void CRSFHandset::Begin()
{
    if (firmwareOptions.uart_baud != 0) {
        UARTrequestedBaud = firmwareOptions.uart_baud;
    }

    DBGLN("About to start CRSF task...");

    addDevice(CRSF_ADDRESS_ELRS_LUA);
    addDevice(CRSF_ADDRESS_RADIO_TRANSMITTER);
    crsfRouter.addConnector(this);

    UARTwdtLastChecked = millis() + UARTwdtInterval; 

    // Assuming GPIO macros are defined in your target configuration
    halfDuplex = (GPIO_PIN_RCSIGNAL_TX == GPIO_PIN_RCSIGNAL_RX);

    noInterrupts(); // STM32 replacement for portDISABLE_INTERRUPTS
    
    // STM32duino specific: remap pins before begin if they aren't default
    // Ensure GPIO_PIN_RCSIGNAL_RX/TX are defined in your hardware target file
    Port.setRx(GPIO_PIN_RCSIGNAL_RX);
    Port.setTx(GPIO_PIN_RCSIGNAL_TX);

    Port.begin(UARTrequestedBaud);
    Port.setTimeout(0);
    
    if (halfDuplex)
    {
        duplex_set_RX();
    }
    
    interrupts(); // STM32 replacement for portENABLE_INTERRUPTS
    flush_port_input();
}

void CRSFHandset::End()
{
    uint32_t startTime = millis();
    while (SerialOutFIFO.peek() > 0)
    {
        handleInput();
        if (millis() - startTime > 1000)
        {
            break;
        }
    }
    DBGLN("CRSF UART END");
}

void CRSFHandset::flush_port_input()
{
    // Make sure there is no garbage on the UART at the start
    while (Port.available())
    {
        Port.read();
    }
}

void CRSFHandset::forwardMessage(const crsf_header_t *message)
{
    if (controllerConnected)
    {
        uint8_t size = CRSF_FRAME_SIZE(message->frame_size);
        if (size > CRSF_MAX_PACKET_LEN)
        {
            ERRLN("too large");
            return;
        }

        SerialOutFIFO.lock();
        if (SerialOutFIFO.ensure(size + 1))
        {
            auto data = (uint8_t *)message;
            data[0] = CRSF_SYNC_BYTE;
            SerialOutFIFO.push(size); // length
            SerialOutFIFO.pushBytes(data, size);
        }
        SerialOutFIFO.unlock();
    }
}

void ICACHE_RAM_ATTR CRSFHandset::setPacketInterval(int32_t PacketInterval)
{
    RequestedRCpacketInterval = PacketInterval;
    OpenTXsyncOffset = 0;
    OpenTXsyncWindow = 0;
    OpenTXsyncWindowSize = std::max((int32_t)1, (int32_t)(20000/RequestedRCpacketInterval));
    OpenTXsyncLastSent -= OpenTXsyncPacketInterval;
    adjustMaxPacketSize();
}

void ICACHE_RAM_ATTR CRSFHandset::JustSentRFpacket()
{
    uint32_t last = dataLastRecv;
    uint32_t m = micros();
    auto delta = (int32_t)(m - last);

    if (delta >= (int32_t)RequestedRCpacketInterval)
    {
        OpenTXsyncOffset = -(delta % RequestedRCpacketInterval) * 10;
        OpenTXsyncWindow = 0;
        OpenTXsyncLastSent -= OpenTXsyncPacketInterval;
#ifdef DEBUG_OPENTX_SYNC
        DBGLN("Missed packet, forced resync (%d)!", delta);
#endif
    }
    else
    {
        OpenTXsyncWindow = std::min(OpenTXsyncWindow + 1, (int32_t)OpenTXsyncWindowSize);
        OpenTXsyncOffset = ((OpenTXsyncOffset * (OpenTXsyncWindow-1)) + delta * 10) / OpenTXsyncWindow;
    }
}

void CRSFHandset::sendSyncPacketToTX() 
{
    const uint32_t now = millis();
    if (now - OpenTXsyncLastSent >= OpenTXsyncPacketInterval)
    {
        int32_t packetRate = RequestedRCpacketInterval * 10; 
        int32_t offset = OpenTXsyncOffset - OpenTXsyncOffsetSafeMargin; 
#ifdef DEBUG_OPENTX_SYNC
        DBGLN("Offset %d", offset);
#endif

        CRSF_MK_EXT_FRAME_T(crsf_sync_packet_t) sync_packet = {
            .h = {
                CRSF_ADDRESS_RADIO_TRANSMITTER,
                CRSF_EXT_FRAME_SIZE(sizeof(crsf_sync_packet_t)),
                CRSF_FRAMETYPE_HANDSET,
                CRSF_ADDRESS_RADIO_TRANSMITTER,
                CRSF_ADDRESS_CRSF_TRANSMITTER,
            },
            .p = {
                .subType = CRSF_HANDSET_SUBCMD_TIMING,
                .rate = htobe32(packetRate),
                .offset = htobe32(offset)
            },
            .crc = crsfRouter.crsf_crc.calc((uint8_t *)&sync_packet + CRSF_TELEMETRY_TYPE_INDEX, sizeof(sync_packet)-3)
        };
        crsfRouter.deliverMessageTo(CRSF_ADDRESS_RADIO_TRANSMITTER, (crsf_header_t *)&sync_packet);

        OpenTXsyncLastSent = now;
    }
}

bool CRSFHandset::ProcessPacket()
{
    dataLastRecv = micros();

    if (!controllerConnected)
    {
        controllerConnected = true;
        DBGLN("CRSF UART Connected");
        if (connected) connected();
    }

    crsfRouter.processMessage(this, (crsf_header_t *)&inBuffer);

    return true;
}

void CRSFHandset::alignBufferToSync(uint8_t startIdx)
{
    for (unsigned int i=startIdx ; i<SerialInPacketPtr ; i++)
    {
        if (inBuffer[i] == CRSF_ADDRESS_CRSF_TRANSMITTER || inBuffer[i] == CRSF_SYNC_BYTE)
        {
            SerialInPacketPtr -= i;
            memmove(inBuffer, &inBuffer[i], SerialInPacketPtr);
            return;
        }
    }
    SerialInPacketPtr = 0;
}

void CRSFHandset::handleInput()
{
    if (UARTwdt())
    {
        return;
    }

    if (transmitting)
    {
        // STM32: Check if transmission is complete using standard Arduino API
        // flush() on STM32 wait for transmission to complete.
        // availableForWrite() < buffer_size implies data is still being sent.
        // A simpler non-blocking check isn't standard, but flushing and switching is safe.
        Port.flush(); 
        
        // All done transmitting; go back to receive mode
        transmitting = false;
        duplex_set_RX();
        flush_port_input();
    }

    // Add new data, and then discard bytes until we start with header byte
    auto toRead = std::min(Port.available(), CRSF_MAX_PACKET_LEN - SerialInPacketPtr);
    SerialInPacketPtr += Port.readBytes(&inBuffer[SerialInPacketPtr], toRead);
    alignBufferToSync(0);

    if (SerialInPacketPtr < 3)
        return;

    const uint32_t totalLen = inBuffer[1] + 2;
    if (totalLen < 4 || totalLen > CRSF_MAX_PACKET_LEN)
    {
        alignBufferToSync(1);
        return;
    }

    if (SerialInPacketPtr < totalLen)
        return;

    uint8_t CalculatedCRC = crsfRouter.crsf_crc.calc(&inBuffer[2], totalLen - 3);
    if (CalculatedCRC == inBuffer[totalLen - 1])
    {
        GoodPktsCount++;
        ProcessPacket();
        handleOutput(totalLen);
    }
    else
    {
        DBGLN("UART CRC failure");
        BadPktsCount++;
    }

    SerialInPacketPtr -= totalLen;
    memmove(inBuffer, &inBuffer[totalLen], SerialInPacketPtr);
}

void CRSFHandset::handleOutput(const uint32_t receivedBytes)
{
    static uint8_t CRSFoutBuffer[CRSF_MAX_PACKET_LEN] = {0};
    static uint8_t packageLengthRemaining = 0;
    static uint8_t sendingOffset = 0;

    if (!controllerConnected)
    {
        SerialOutFIFO.lock();
        SerialOutFIFO.flush();
        SerialOutFIFO.unlock();
        return;
    }

    if (packageLengthRemaining == 0 && SerialOutFIFO.size() == 0)
    {
        sendSyncPacketToTX(); 
    }

    if (packageLengthRemaining > 0 || SerialOutFIFO.size() > 0) {
        uint8_t periodBytesRemaining = HANDSET_TELEMETRY_FIFO_SIZE;
        if (halfDuplex)
        {
            periodBytesRemaining = std::min(maxPeriodBytes - receivedBytes % maxPeriodBytes, (uint32_t)maxPacketBytes);
            periodBytesRemaining = std::max(periodBytesRemaining, (uint8_t)10);
            if (!transmitting)
            {
                transmitting = true;
                duplex_set_TX();
            }
        }

        do
        {
            SerialOutFIFO.lock();
            if (packageLengthRemaining == 0)
            {
                packageLengthRemaining = SerialOutFIFO.pop();
                SerialOutFIFO.popBytes(CRSFoutBuffer, packageLengthRemaining);
                sendingOffset = 0;
            }
            SerialOutFIFO.unlock();

            uint8_t writeLength = std::min(packageLengthRemaining, periodBytesRemaining);

            Port.write(CRSFoutBuffer + sendingOffset, writeLength);
            if (PortSecondary)
            {
                PortSecondary->write(CRSFoutBuffer + sendingOffset, writeLength);
            }

            sendingOffset += writeLength;
            packageLengthRemaining -= writeLength;
            periodBytesRemaining -= writeLength;
        } while(periodBytesRemaining != 0 && SerialOutFIFO.size() != 0);
    }
}

void CRSFHandset::duplex_set_RX() const
{
    // Replaced ESP32 Matrix IO with Standard Arduino GPIO
    pinMode(GPIO_PIN_RCSIGNAL_RX, INPUT_PULLUP);
}

void CRSFHandset::duplex_set_TX() const
{
    // Replaced ESP32 Matrix IO with Standard Arduino GPIO
    // For STM32, OUTPUT is usually Push-Pull. 
    // If external hardware uses a pullup resistor for 1-wire, use OUTPUT_OPEN_DRAIN if supported,
    // otherwise OUTPUT is fine as long as RX doesn't fight it.
    pinMode(GPIO_PIN_RCSIGNAL_TX, OUTPUT);
}

int CRSFHandset::getMinPacketInterval() const
{
    if (halfDuplex && UARTrequestedBaud == 115200) 
    {
        return 5000;
    }
    if (UARTrequestedBaud == 115200) 
    {
        return 4000;
    }
    if (UARTrequestedBaud == 400000 || UARTrequestedBaud == 420000) 
    {
        return 2000;
    }
    return 1;   
}

void ICACHE_RAM_ATTR CRSFHandset::adjustMaxPacketSize()
{
    const int LUA_CHUNK_QUERY_SIZE = 26;
    maxPeriodBytes = std::min((int)(UARTrequestedBaud / 10 / (1000000/RequestedRCpacketInterval) * 87 / 100), HANDSET_TELEMETRY_FIFO_SIZE);
    maxPacketBytes = std::min(maxPeriodBytes - max(maxPeriodBytes / 2, LUA_CHUNK_QUERY_SIZE), CRSF_MAX_PACKET_LEN);
    DBGLN("Adjusted max packet size %u-%u", maxPacketBytes, maxPeriodBytes);
}

// Fallback Cyclic Autobaud for STM32 
// (Hardware pulse measurement is too specific to ESP32 SOC registers)
uint32_t CRSFHandset::autobaud() {
    UARTcurrentBaudIdx = (UARTcurrentBaudIdx + 1) % ARRAY_SIZE(TxToHandsetBauds);
    return TxToHandsetBauds[UARTcurrentBaudIdx];
}

bool CRSFHandset::UARTwdt()
{
    bool retval = false;
#if !defined(DEBUG_TX_FREERUN)
    uint32_t now = millis();
    if (now - UARTwdtLastChecked > UARTwdtInterval)
    {
        if ((connectionState != wifiUpdate) && (BadPktsCount >= GoodPktsCount || !controllerConnected))
        {
            DBGLN("Too many bad UART RX packets!");

            if (controllerConnected)
            {
                DBGLN("CRSF UART Disconnected");
                if (disconnected) disconnected();
                controllerConnected = false;
            }

            UARTrequestedBaud = autobaud();
            if (UARTrequestedBaud != 0)
            {
                DBGLN("UART WDT: Switch to: %d baud", UARTrequestedBaud);

                adjustMaxPacketSize();

                SerialOutFIFO.flush();
                Port.flush();
                Port.begin(UARTrequestedBaud);
                if (halfDuplex)
                {
                    duplex_set_RX();
                }
                flush_port_input();
            }
            retval = true;
        }
#ifdef DEBUG_OPENTX_SYNC
        if (abs((int)((1000000 / (ExpressLRS_currAirRate_Modparams->interval * ExpressLRS_currAirRate_Modparams->numOfSends)) - (int)GoodPktsCount)) > 1)
#endif
            DBGVLN("UART STATS Bad:Good = %u:%u", BadPktsCount, GoodPktsCount);

        UARTwdtLastChecked = now;
        if (retval)
        {
            UARTwdtLastChecked -= 3 * (UARTwdtInterval >> 2);
        }

        GoodPktsCountResult = GoodPktsCount;
        BadPktsCountResult = BadPktsCount;
        BadPktsCount = 0;
        GoodPktsCount = 0;
    }
#endif
    return retval;
}
#endif