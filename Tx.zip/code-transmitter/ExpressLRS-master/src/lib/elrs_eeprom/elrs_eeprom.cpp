#include "elrs_eeprom.h"
#include "targets.h"
#include "logging.h"
#include <Arduino.h>

#if !defined(TARGET_NATIVE)
#include <EEPROM.h>

// Fallback size if not defined
#ifndef RESERVED_EEPROM_SIZE
#define RESERVED_EEPROM_SIZE 4096
#endif

// --- Shadow Buffer Strategy ---
// STM32 EEPROM library writes immediately, which wears out flash if done too often.
// We create a RAM buffer to act like the ESP32 "commit" system.
static uint8_t eeprom_shadow[RESERVED_EEPROM_SIZE];
static bool is_shadow_loaded = false;

void ELRS_EEPROM::Begin()
{
    // STM32's EEPROM.begin() does not take arguments or is not needed.
    // We use this step to load the hardware EEPROM content into our RAM shadow.
    for (uint32_t i = 0; i < RESERVED_EEPROM_SIZE; i++) {
        eeprom_shadow[i] = EEPROM.read(i);
    }
    is_shadow_loaded = true;
}

uint8_t ELRS_EEPROM::ReadByte(const uint32_t address)
{
    if (address >= RESERVED_EEPROM_SIZE)
    {
        return 0;
    }
    
    // Safety: Load shadow if Begin() wasn't called yet
    if (!is_shadow_loaded) {
        Begin();
    }
    
    return eeprom_shadow[address];
}

void ELRS_EEPROM::WriteByte(const uint32_t address, const uint8_t value)
{
    if (address >= RESERVED_EEPROM_SIZE)
    {
        return;
    }

    if (!is_shadow_loaded) {
        Begin();
    }

    // Only update the RAM buffer. We do NOT write to Flash yet.
    eeprom_shadow[address] = value;
}

void ELRS_EEPROM::Commit()
{
    if (!is_shadow_loaded) return;

    // Sync RAM Shadow to Actual Hardware EEPROM
    for (uint32_t i = 0; i < RESERVED_EEPROM_SIZE; i++) {
        // Read actual hardware value first
        uint8_t hwVal = EEPROM.read(i);
        
        // Optimization: Only write if the value has actually changed.
        // This saves time and significantly extends Flash lifespan.
        if (hwVal != eeprom_shadow[i]) {
            EEPROM.write(i, eeprom_shadow[i]);
        }
    }
    // Note: STM32duino EEPROM library writes are immediate; no explicit .commit() call is needed on the object itself.
}

#endif /* !TARGET_NATIVE */