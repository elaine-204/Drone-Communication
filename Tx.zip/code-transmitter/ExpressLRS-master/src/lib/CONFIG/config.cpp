#include "config.h"
#include "config_legacy.h"
#include "common.h"
#include "device.h"
#include "POWERMGNT.h"
#include "OTA.h"
#include "helpers.h"
#include "logging.h"

#if defined(TARGET_TX)

#define ALL_CHANGED         (EVENT_CONFIG_MODEL_CHANGED | EVENT_CONFIG_VTX_CHANGED | EVENT_CONFIG_MAIN_CHANGED | EVENT_CONFIG_FAN_CHANGED | EVENT_CONFIG_MOTION_CHANGED | EVENT_CONFIG_BUTTON_CHANGED | EVENT_CONFIG_VERSION_CHANGED)

// --- Helper Functions for Version Upgrades ---
static uint8_t RateV6toV7(uint8_t rateV6)
{
#if defined(RADIO_SX128X) || defined(RADIO_LR1121)
    if (rateV6 == 0) return 0;
    return rateV6 + 1;
#else // RADIO_2400
    switch (rateV6)
    {
        case 0: return 4; // 500Hz
        case 1: return 6; // 250Hz
        case 2: return 7; // 150Hz
        case 3: return 9; // 50Hz
        default: return 4; // 500Hz
    }
#endif
}

static uint8_t RatioV6toV7(uint8_t ratioV6) { return ratioV6 + 1; }

static uint8_t SwitchesV6toV7(uint8_t switchesV6)
{
    switch (switchesV6)
    {
        case 1: return (uint8_t)smHybridOr16ch;
        case 2:
        default: return (uint8_t)smWideOr8ch;
    }
}

static void ModelV6toV7(v6_model_config_t const * const v6, v7_model_config_t * const v7)
{
    v7->rate = RateV6toV7(v6->rate);
    v7->tlm = RatioV6toV7(v6->tlm);
    v7->power = v6->power;
    v7->switchMode = SwitchesV6toV7(v6->switchMode);
    v7->modelMatch = v6->modelMatch;
    v7->dynamicPower = v6->dynamicPower;
    v7->boostChannel = v6->boostChannel;
}

static void ModelV7toV8(v7_model_config_t const * const v7, model_config_t * const v8)
{
    uint8_t newRate = v7->rate;
    // Map old rates to new rates based on radio type if needed
    // For SX1280 (2.4GHz), rates have been relatively stable in mapping indices for recent versions
    // but full mapping would go here. For DIY setup, defaults will likely reset anyway.
    v8->rate = newRate;
    v8->tlm = v7->tlm;
    v8->power = v7->power;
    v8->switchMode = v7->switchMode;
    v8->boostChannel = v7->boostChannel;
    v8->dynamicPower = v7->dynamicPower;
    v8->modelMatch = v7->modelMatch;
    v8->txAntenna = v7->txAntenna;
    v8->ptrStartChannel = v7->ptrStartChannel;
    v8->ptrEnableChannel = v7->ptrEnableChannel;
    v8->linkMode = v7->linkMode;
}

// --- Class Implementation ---

TxConfig::TxConfig()
{
    // Point m_model to a valid location initially to prevent null pointer deref
    m_model = &m_config.model_config[0];
    m_eeprom = nullptr; // Default to null
}

void TxConfig::Load()
{
    m_modified = 0;

    // Safety: If EEPROM provider is not set, load defaults into RAM and exit
    if (!m_eeprom) {
        SetDefaults(false);
        return;
    }

    m_eeprom->Get(0, m_config);

    uint32_t version = 0;
    if ((m_config.version & CONFIG_MAGIC_MASK) == TX_CONFIG_MAGIC)
        version = m_config.version & ~CONFIG_MAGIC_MASK;
    DBGLN("Config version %u", version);

    if (version == TX_CONFIG_VERSION)
        return;

    if (version < 5 || version > TX_CONFIG_VERSION)
    {
        SetDefaults(true);
        return;
    }

    SetDefaults(false);

    if (version == 5) { UpgradeEepromV5ToV6(); version = 6; }
    if (version == 6) { UpgradeEepromV6ToV7(); version = 7; }
    if (version == 7) { UpgradeEepromV7ToV8(); }
}

void TxConfig::UpgradeEepromV5ToV6()
{
    if (!m_eeprom) return;
    v5_tx_config_t v5Config;
    v6_tx_config_t v6Config = { 0 };
    m_eeprom->Get(0, v5Config);
    memcpy(&v6Config, &v5Config, sizeof(v5Config));
    v6Config.version = 6U | TX_CONFIG_MAGIC;
    m_eeprom->Put(0, v6Config);
    m_eeprom->Commit();
}

void TxConfig::UpgradeEepromV6ToV7()
{
    if (!m_eeprom) return;
    v6_tx_config_t v6Config;
    v7_tx_config_t v7Config = { 0 };
    m_eeprom->Get(0, v6Config);

    #define LAZY(member) v7Config.member = v6Config.member
    LAZY(vtxBand); LAZY(vtxChannel); LAZY(vtxPower); LAZY(vtxPitmode);
    LAZY(powerFanThreshold); LAZY(fanMode); LAZY(motionMode);
    LAZY(dvrAux); LAZY(dvrStartDelay); LAZY(dvrStopDelay);
    #undef LAZY

    for (unsigned i=0; i<CONFIG_TX_MODEL_CNT; i++)
    {
        ModelV6toV7(&v6Config.model_config[i], &v7Config.model_config[i]);
    }

    m_modified = ALL_CHANGED;
    m_config.version = 7U | TX_CONFIG_MAGIC;
    m_eeprom->Put(0, v7Config);
    m_eeprom->Commit();
}

void TxConfig::UpgradeEepromV7ToV8()
{
    if (!m_eeprom) return;
    v7_tx_config_t v7Config;
    m_eeprom->Get(0, v7Config);

    #define LAZY(member) m_config.member = v7Config.member
    LAZY(vtxBand); LAZY(vtxChannel); LAZY(vtxPower); LAZY(vtxPitmode);
    LAZY(powerFanThreshold); LAZY(fanMode); LAZY(motionMode);
    LAZY(dvrAux); LAZY(dvrStartDelay); LAZY(dvrStopDelay);
    #undef LAZY

    for (unsigned i=0; i<CONFIG_TX_MODEL_CNT; i++)
    {
        ModelV7toV8(&v7Config.model_config[i], &m_config.model_config[i]);
    }

    m_modified = ALL_CHANGED;
    m_config.version = 8U | TX_CONFIG_MAGIC;
    Commit();
}

uint32_t TxConfig::Commit()
{
    if (!m_modified) return 0;
    if (!m_eeprom) return 0; // Safety check

    m_eeprom->Put(0, m_config);
    m_eeprom->Commit();

    uint32_t changes = m_modified;
    m_modified = 0;
    return changes;
}

// Setters
void TxConfig::SetRate(uint8_t rate) { if (GetRate() != rate) { m_model->rate = rate; m_modified |= EVENT_CONFIG_MODEL_CHANGED; } }
void TxConfig::SetTlm(uint8_t tlm) { if (GetTlm() != tlm) { m_model->tlm = tlm; m_modified |= EVENT_CONFIG_MODEL_CHANGED; } }
void TxConfig::SetPower(uint8_t power) { if (GetPower() != power) { m_model->power = power; m_modified |= EVENT_CONFIG_MODEL_CHANGED; } }
void TxConfig::SetDynamicPower(bool dynamicPower) { if (GetDynamicPower() != dynamicPower) { m_model->dynamicPower = dynamicPower; m_modified |= EVENT_CONFIG_MODEL_CHANGED; } }
void TxConfig::SetBoostChannel(uint8_t boostChannel) { if (GetBoostChannel() != boostChannel) { m_model->boostChannel = boostChannel; m_modified |= EVENT_CONFIG_MODEL_CHANGED; } }
void TxConfig::SetSwitchMode(uint8_t switchMode) { if (GetSwitchMode() != switchMode) { m_model->switchMode = switchMode; m_modified |= EVENT_CONFIG_MODEL_CHANGED; } }
void TxConfig::SetAntennaMode(uint8_t txAntenna) { if (GetAntennaMode() != txAntenna) { m_model->txAntenna = txAntenna; m_modified |= EVENT_CONFIG_MODEL_CHANGED; } }
void TxConfig::SetModelMatch(bool modelMatch) { if (GetModelMatch() != modelMatch) { m_model->modelMatch = modelMatch; m_modified |= EVENT_CONFIG_MODEL_CHANGED; } }
void TxConfig::SetVtxBand(uint8_t vtxBand) { if (m_config.vtxBand != vtxBand) { m_config.vtxBand = vtxBand; m_modified |= EVENT_CONFIG_VTX_CHANGED; } }
void TxConfig::SetVtxChannel(uint8_t vtxChannel) { if (m_config.vtxChannel != vtxChannel) { m_config.vtxChannel = vtxChannel; m_modified |= EVENT_CONFIG_VTX_CHANGED; } }
void TxConfig::SetVtxPower(uint8_t vtxPower) { if (m_config.vtxPower != vtxPower) { m_config.vtxPower = vtxPower; m_modified |= EVENT_CONFIG_VTX_CHANGED; } }
void TxConfig::SetVtxPitmode(uint8_t vtxPitmode) { if (m_config.vtxPitmode != vtxPitmode) { m_config.vtxPitmode = vtxPitmode; m_modified |= EVENT_CONFIG_VTX_CHANGED; } }
void TxConfig::SetPowerFanThreshold(uint8_t powerFanThreshold) { if (m_config.powerFanThreshold != powerFanThreshold) { m_config.powerFanThreshold = powerFanThreshold; m_modified |= EVENT_CONFIG_FAN_CHANGED; } }
void TxConfig::SetFanMode(uint8_t fanMode) { if (m_config.fanMode != fanMode) { m_config.fanMode = fanMode; m_modified |= EVENT_CONFIG_FAN_CHANGED; } }
void TxConfig::SetMotionMode(uint8_t motionMode) { if (m_config.motionMode != motionMode) { m_config.motionMode = motionMode; m_modified |= EVENT_CONFIG_MOTION_CHANGED; } }
void TxConfig::SetDvrAux(uint8_t dvrAux) { if (GetDvrAux() != dvrAux) { m_config.dvrAux = dvrAux; m_modified |= EVENT_CONFIG_MAIN_CHANGED; } }
void TxConfig::SetDvrStartDelay(uint8_t dvrStartDelay) { if (GetDvrStartDelay() != dvrStartDelay) { m_config.dvrStartDelay = dvrStartDelay; m_modified |= EVENT_CONFIG_MAIN_CHANGED; } }
void TxConfig::SetDvrStopDelay(uint8_t dvrStopDelay) { if (GetDvrStopDelay() != dvrStopDelay) { m_config.dvrStopDelay = dvrStopDelay; m_modified |= EVENT_CONFIG_MAIN_CHANGED; } }
void TxConfig::SetBackpackDisable(bool backpackDisable) { if (m_config.backpackDisable != backpackDisable) { m_config.backpackDisable = backpackDisable; m_modified |= EVENT_CONFIG_MAIN_CHANGED; } }
void TxConfig::SetBackpackTlmMode(uint8_t mode) { if (m_config.backpackTlmMode != mode) { m_config.backpackTlmMode = mode; m_modified |= EVENT_CONFIG_MAIN_CHANGED; } }

void TxConfig::SetLinkMode(uint8_t linkMode)
{
    if (GetLinkMode() != linkMode)
    {
        m_model->linkMode = linkMode;
        if (linkMode == TX_MAVLINK_MODE)
        {
            m_model->tlm = TLM_RATIO_1_2;
            m_model->switchMode = smHybridOr16ch; 
        }
        m_modified |= EVENT_CONFIG_MODEL_CHANGED | EVENT_CONFIG_MAIN_CHANGED;
    }
}

void TxConfig::SetStorageProvider(ELRS_EEPROM *eeprom)
{
    if (eeprom) m_eeprom = eeprom;
}

void TxConfig::SetButtonActions(uint8_t button, tx_button_color_t *action)
{
    if (m_config.buttonColors[button].raw != action->raw) {
        m_config.buttonColors[button].raw = action->raw;
        m_modified |= EVENT_CONFIG_BUTTON_CHANGED;
    }
}

void TxConfig::SetPTRStartChannel(uint8_t ptrStartChannel)
{
    if (ptrStartChannel != m_model->ptrStartChannel) {
        m_model->ptrStartChannel = ptrStartChannel;
        m_modified |= EVENT_CONFIG_MODEL_CHANGED;
    }
}

void TxConfig::SetPTREnableChannel(uint8_t ptrEnableChannel)
{
    if (ptrEnableChannel != m_model->ptrEnableChannel) {
        m_model->ptrEnableChannel = ptrEnableChannel;
        m_modified |= EVENT_CONFIG_MODEL_CHANGED;
    }
}

void TxConfig::SetDefaults(bool commit)
{
    memset(&m_config, 0, sizeof(m_config));
    m_config.version = TX_CONFIG_VERSION | TX_CONFIG_MAGIC;
    m_config.powerFanThreshold = PWR_250mW;
    m_modified = ALL_CHANGED;

    // Defaults for buttons
    tx_button_color_t default_actions1 = { .val = { .color = 226, .actions = { {false, 2, ACTION_BIND}, {true, 0, ACTION_INCREASE_POWER} } } };
    m_config.buttonColors[0].raw = default_actions1.raw;
    
    tx_button_color_t default_actions2 = { .val = { .color = 3, .actions = { {false, 1, ACTION_GOTO_VTX_CHANNEL}, {true, 0, ACTION_SEND_VTX} } } };
    m_config.buttonColors[1].raw = default_actions2.raw;

    for (unsigned i=0; i<CONFIG_TX_MODEL_CNT; i++)
    {
        SetModelId(i);
        #if defined(RADIO_SX128X)
            SetRate(enumRatetoIndex(RATE_LORA_2G4_250HZ));
        #endif
        SetPower(POWERMGNT::getDefaultPower());
    }

    if (commit && m_eeprom)
    {
        Commit();
    }

    SetModelId(0);
    m_modified = 0;
}

bool TxConfig::SetModelId(uint8_t modelId)
{
    model_config_t *newModel = &m_config.model_config[modelId];
    if (newModel != m_model)
    {
        m_model = newModel;
        m_modelId = modelId;
        return true;
    }
    return false;
}
#endif