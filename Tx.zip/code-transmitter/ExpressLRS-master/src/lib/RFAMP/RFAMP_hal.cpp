#ifndef UNIT_TEST

#include "RFAMP_hal.h"
#include "logging.h"
#include <Arduino.h> // Ensure Arduino core is included for digitalRead/Write

RFAMP_hal *RFAMP_hal::instance = nullptr;

RFAMP_hal::RFAMP_hal()
{
    instance = this;
}

void RFAMP_hal::init()
{
    DBGLN("RFAMP_hal Init");

    // Initialize state tracking variables
    rx_enabled = false;
    tx_enabled = false;

    // --- Configure Pins ---
    if (GPIO_PIN_PA_ENABLE != UNDEF_PIN)
    {
        pinMode(GPIO_PIN_PA_ENABLE, OUTPUT);
        digitalWrite(GPIO_PIN_PA_ENABLE, LOW); // Default OFF
    }

    if (GPIO_PIN_TX_ENABLE != UNDEF_PIN)
    {
        pinMode(GPIO_PIN_TX_ENABLE, OUTPUT);
        digitalWrite(GPIO_PIN_TX_ENABLE, LOW); // Default OFF
    }

    if (GPIO_PIN_RX_ENABLE != UNDEF_PIN)
    {
        pinMode(GPIO_PIN_RX_ENABLE, OUTPUT);
        digitalWrite(GPIO_PIN_RX_ENABLE, LOW); // Default OFF
    }

    // Support for 2nd Radio (Diversity) if pins are defined
    if (GPIO_PIN_TX_ENABLE_2 != UNDEF_PIN)
    {
        pinMode(GPIO_PIN_TX_ENABLE_2, OUTPUT);
        digitalWrite(GPIO_PIN_TX_ENABLE_2, LOW);
    }

    if (GPIO_PIN_RX_ENABLE_2 != UNDEF_PIN)
    {
        pinMode(GPIO_PIN_RX_ENABLE_2, OUTPUT);
        digitalWrite(GPIO_PIN_RX_ENABLE_2, LOW);
    }
}

void ICACHE_RAM_ATTR RFAMP_hal::TXenable(SX12XX_Radio_Number_t radioNumber)
{
    // 1. Disable RX first if it was enabled
    if (rx_enabled)
    {
        if (GPIO_PIN_RX_ENABLE != UNDEF_PIN) digitalWrite(GPIO_PIN_RX_ENABLE, LOW);
        if (GPIO_PIN_RX_ENABLE_2 != UNDEF_PIN) digitalWrite(GPIO_PIN_RX_ENABLE_2, LOW);
        rx_enabled = false;
    }

    // 2. Enable PA (Power Amplifier) global enable
    if (GPIO_PIN_PA_ENABLE != UNDEF_PIN)
    {
        digitalWrite(GPIO_PIN_PA_ENABLE, HIGH);
    }

    // 3. Enable TX for specific radio
    if (!tx_enabled)
    {
        if (GPIO_PIN_TX_ENABLE != UNDEF_PIN)
        {
            digitalWrite(GPIO_PIN_TX_ENABLE, HIGH);
        }
        // Handle 2nd radio if present
        if (GPIO_PIN_TX_ENABLE_2 != UNDEF_PIN && (radioNumber == SX12XX_Radio_2 || radioNumber == SX12XX_Radio_All))
        {
            digitalWrite(GPIO_PIN_TX_ENABLE_2, HIGH);
        }
        tx_enabled = true;
    }
}

void ICACHE_RAM_ATTR RFAMP_hal::RXenable()
{
    // 1. Disable TX first
    if (tx_enabled)
    {
        if (GPIO_PIN_TX_ENABLE != UNDEF_PIN) digitalWrite(GPIO_PIN_TX_ENABLE, LOW);
        if (GPIO_PIN_TX_ENABLE_2 != UNDEF_PIN) digitalWrite(GPIO_PIN_TX_ENABLE_2, LOW);
        tx_enabled = false;
    }

    // 2. Enable PA (Some modules need PA_ENABLE high for LNA too)
    if (GPIO_PIN_PA_ENABLE != UNDEF_PIN)
    {
        digitalWrite(GPIO_PIN_PA_ENABLE, HIGH);
    }

    // 3. Enable RX
    if (!rx_enabled)
    {
        if (GPIO_PIN_RX_ENABLE != UNDEF_PIN)
        {
            digitalWrite(GPIO_PIN_RX_ENABLE, HIGH);
        }
        if (GPIO_PIN_RX_ENABLE_2 != UNDEF_PIN)
        {
            digitalWrite(GPIO_PIN_RX_ENABLE_2, HIGH);
        }
        rx_enabled = true;
    }
}

void ICACHE_RAM_ATTR RFAMP_hal::TXRXdisable()
{
    // Disable Everything
    if (GPIO_PIN_PA_ENABLE != UNDEF_PIN) digitalWrite(GPIO_PIN_PA_ENABLE, LOW);
    
    if (GPIO_PIN_TX_ENABLE != UNDEF_PIN) digitalWrite(GPIO_PIN_TX_ENABLE, LOW);
    if (GPIO_PIN_RX_ENABLE != UNDEF_PIN) digitalWrite(GPIO_PIN_RX_ENABLE, LOW);
    
    if (GPIO_PIN_TX_ENABLE_2 != UNDEF_PIN) digitalWrite(GPIO_PIN_TX_ENABLE_2, LOW);
    if (GPIO_PIN_RX_ENABLE_2 != UNDEF_PIN) digitalWrite(GPIO_PIN_RX_ENABLE_2, LOW);

    rx_enabled = false;
    tx_enabled = false;
}

#endif // UNIT_TEST