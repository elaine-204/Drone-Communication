// ============================================================
//  sx1280.cpp  –  Standalone SX1280 LoRa driver (STM32F4)
// ============================================================

#include "SX.h"

// ── NSS helpers ─────────────────────────────────────────────
static inline void nss_low (void) { HAL_GPIO_WritePin(SX_NSS_PORT,   SX_NSS_PIN,   GPIO_PIN_RESET); }
static inline void nss_high(void) { HAL_GPIO_WritePin(SX_NSS_PORT,   SX_NSS_PIN,   GPIO_PIN_SET);   }

// ============================================================
//  Low-level primitives
// ============================================================

// Block until BUSY pin goes low.  100 ms hard timeout to avoid lockup.
void SX1280_WaitBusy(void) {
    uint32_t t = HAL_GetTick();
    while (HAL_GPIO_ReadPin(SX_BUSY_PORT, SX_BUSY_PIN) == GPIO_PIN_SET) {
        if (HAL_GetTick() - t > 100) return;
    }
}

// Write command followed by optional data bytes
void SX1280_WriteCmd(uint8_t cmd, const uint8_t *data, uint8_t len) {
    SX1280_WaitBusy();
    nss_low();
    HAL_SPI_Transmit(&hspi1, &cmd, 1, HAL_MAX_DELAY);
    if (data && len) {
        HAL_SPI_Transmit(&hspi1, (uint8_t *)data, len, HAL_MAX_DELAY);
    }
    nss_high();
}

// Read command: send cmd + status NOP, then clock out 'len' response bytes
void SX1280_ReadCmd(uint8_t cmd, uint8_t *data, uint8_t len) {
    SX1280_WaitBusy();
    nss_low();
    uint8_t nop = 0x00;
    HAL_SPI_Transmit(&hspi1, &cmd, 1, HAL_MAX_DELAY);
    HAL_SPI_Transmit(&hspi1, &nop, 1, HAL_MAX_DELAY);   // status byte (discard)
    HAL_SPI_Receive (&hspi1, data, len, HAL_MAX_DELAY);
    nss_high();
}

// Write to internal register map (e.g., sync word registers)
void SX1280_WriteReg(uint16_t addr, const uint8_t *data, uint8_t len) {
    SX1280_WaitBusy();
    nss_low();
    uint8_t hdr[3] = {
        SX_CMD_WRITE_REGISTER,
        (uint8_t)(addr >> 8),
        (uint8_t)(addr & 0xFF)
    };
    HAL_SPI_Transmit(&hspi1, hdr, 3, HAL_MAX_DELAY);
    HAL_SPI_Transmit(&hspi1, (uint8_t *)data, len, HAL_MAX_DELAY);
    nss_high();
}

// Write bytes into the radio TX/RX FIFO buffer at given offset
void SX1280_WriteBuf(uint8_t offset, const uint8_t *data, uint8_t len) {
    SX1280_WaitBusy();
    nss_low();
    uint8_t hdr[2] = {SX_CMD_WRITE_BUFFER, offset};
    HAL_SPI_Transmit(&hspi1, hdr, 2, HAL_MAX_DELAY);
    HAL_SPI_Transmit(&hspi1, (uint8_t *)data, len, HAL_MAX_DELAY);
    nss_high();
}

// ============================================================
//  Reset
// ============================================================
void SX1280_Reset(void) {
    HAL_GPIO_WritePin(SX_RESET_PORT, SX_RESET_PIN, GPIO_PIN_RESET);
    HAL_Delay(10);
    HAL_GPIO_WritePin(SX_RESET_PORT, SX_RESET_PIN, GPIO_PIN_SET);
    HAL_Delay(20);
    SX1280_WaitBusy();   // wait until BUSY clears after POR
}

// ============================================================
//  High-level Init
//  freq_hz  : RF centre frequency, e.g. 2450000000 (2.45 GHz)
//  power_dbm: TX power, -18..+13 dBm
// ============================================================
void SX1280_Init(uint32_t freq_hz, int8_t power_dbm) {

    SX1280_Reset();

    // ── 1. Standby (STDBY_RC) ───────────────────────────────
    uint8_t b;
    b = 0x00;
    SX1280_WriteCmd(SX_CMD_SET_STANDBY, &b, 1);

    // ── 2. Packet type = LoRa ────────────────────────────────
    b = SX_PACKET_TYPE_LORA;
    SX1280_WriteCmd(SX_CMD_SET_PACKET_TYPE, &b, 1);

    // ── 3. RF frequency ──────────────────────────────────────
    //  frf_reg = freq_hz * 2^18 / 52_000_000
    //  Use 64-bit intermediate to avoid overflow at 2.4 GHz.
    uint32_t frf = (uint32_t)((uint64_t)freq_hz * 262144ULL / 52000000ULL);
    uint8_t freq_bytes[3] = {
        (uint8_t)(frf >> 16),
        (uint8_t)(frf >>  8),
        (uint8_t)(frf       )
    };
    SX1280_WriteCmd(SX_CMD_SET_RF_FREQUENCY, freq_bytes, 3);

    // ── 4. Modulation params: SF7, BW800, CR 4/5 ────────────
    //  SF7+BW800 gives ~200 kbps air data rate — good for
    //  real-time RC at 100 Hz.  Adjust if needed.
    uint8_t mod[3] = {LORA_SF7, LORA_BW_800, LORA_CR_4_5};
    SX1280_WriteCmd(SX_CMD_SET_MOD_PARAMS, mod, 3);

    // ── 5. Packet params ─────────────────────────────────────
    //  [PreambleLenMsb, PreambleLenLsb, HeaderType,
    //   PayloadLen, CrcMode, InvertIQ]
    //  Preamble = 12 symbols (safe minimum for sync lock)
    //  HeaderType = 0x00 (explicit — length sent in header)
    //  PayloadLen = 32 bytes (16 ch × 2 bytes)
    //  CRC = 0x00 disabled (we do our own framing on RX)
    //  IQ  = 0x00 standard (not inverted)
    uint8_t pkt[7] = {0x00, 0x0C, 0x00, 32, 0x00, 0x00, 0x00};
    SX1280_WriteCmd(SX_CMD_SET_PKT_PARAMS, pkt, 7);

    // ── 6. DIO1 → TxDone IRQ ────────────────────────────────
    //  SetDioIrqParams: irqMask, DIO1mask, DIO2mask, DIO3mask
    uint8_t irq[8] = {
        0xFF, 0xFF,  // irqMask  = all
        0x00, 0x01,  // DIO1     = TxDone
        0x00, 0x00,  // DIO2     = none
        0x00, 0x00   // DIO3     = none
    };
    SX1280_WriteCmd(SX_CMD_SET_DIO_IRQ_PARAMS, irq, 8);

    // ── 7. Buffer base addresses (TX=0x00, RX=0x00) ──────────
    uint8_t buf[2] = {0x00, 0x00};
    SX1280_WriteCmd(SX_CMD_SET_BUFFER_BASE, buf, 2);

    // ── 8. TX power & ramp time ──────────────────────────────
    //  power byte = power_dbm + 18  (0 → -18 dBm, 31 → +13 dBm)
    int8_t p = power_dbm;
    if (p < -18) p = -18;
    if (p >  13) p =  13;
    uint8_t txp[2] = {(uint8_t)(p + 18), SX_RAMP_20_US};
    SX1280_WriteCmd(SX_CMD_SET_TX_PARAMS, txp, 2);
}

// ============================================================
//  Sync word
//  For ELRS-compatible RX use 0x1424.
//  For a fully custom link any 16-bit value is fine.
// ============================================================
void SX1280_SetSyncWord(uint16_t sw) {
    uint8_t d[2] = {(uint8_t)(sw >> 8), (uint8_t)(sw & 0xFF)};
    SX1280_WriteReg(SX_REG_LORA_SYNC_MSB, d, 2);
}

// ============================================================
//  IRQ helpers
// ============================================================
uint16_t SX1280_GetIrq(void) {
    // Full-duplex transaction:
    //  TX: [0x15, NOP, NOP, NOP]
    //  RX: [garbage, status, IrqMsb, IrqLsb]
    uint8_t tx[4] = {SX_CMD_GET_IRQ_STATUS, 0x00, 0x00, 0x00};
    uint8_t rx[4] = {0};
    SX1280_WaitBusy();
    nss_low();
    HAL_SPI_TransmitReceive(&hspi1, tx, rx, 4, HAL_MAX_DELAY);
    nss_high();
    return (uint16_t)((rx[2] << 8) | rx[3]);
}

void SX1280_ClearIrq(uint16_t mask) {
    uint8_t d[2] = {(uint8_t)(mask >> 8), (uint8_t)(mask & 0xFF)};
    SX1280_WriteCmd(SX_CMD_CLR_IRQ_STATUS, d, 2);
}

// ============================================================
//  Transmit
//  Loads 'data' into buffer, kicks SetTx, polls for TxDone.
//  Returns true on success, false on timeout.
// ============================================================
bool SX1280_Transmit(const uint8_t *data, uint8_t len, uint32_t timeout_ms) {

    // Clear any stale IRQ flags
    SX1280_ClearIrq(SX_IRQ_ALL);

    // Load payload into radio buffer at offset 0x00
    SX1280_WriteBuf(0x00, data, len);

    // SetTx with no timeout (PeriodBase=1ms, Count=0 → runs until TxDone)
    uint8_t tx_timeout[3] = {0x02, 0x00, 0x00};
    SX1280_WriteCmd(SX_CMD_SET_TX, tx_timeout, 3);

    // Poll for TxDone
    uint32_t start = HAL_GetTick();
    while ((SX1280_GetIrq() & SX_IRQ_TX_DONE) == 0) {
        if (HAL_GetTick() - start > timeout_ms) {
            SX1280_ClearIrq(SX_IRQ_ALL);
            return false;
        }
    }

    SX1280_ClearIrq(SX_IRQ_TX_DONE);
    return true;
}

void SX1280_SetRfFrequency(uint32_t freq_hz)
{
    // Convert frequency to register value
    uint32_t frf = (uint32_t)((uint64_t)freq_hz * 262144ULL / 52000000ULL);

    uint8_t freq_bytes[3] = {
        (uint8_t)(frf >> 16),
        (uint8_t)(frf >> 8),
        (uint8_t)(frf)
    };

    SX1280_WriteCmd(SX_CMD_SET_RF_FREQUENCY, freq_bytes, 3);
}
