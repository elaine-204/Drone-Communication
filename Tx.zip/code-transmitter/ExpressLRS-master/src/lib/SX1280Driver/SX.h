#pragma once

// ============================================================
//  sx1280.h  –  Standalone SX1280 LoRa driver for STM32F4
//  No ELRS framework dependency.  Pure HAL + SPI.
// ============================================================

#include "stm32f4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

// ── SPI handle (defined in main.cpp) ────────────────────────
extern SPI_HandleTypeDef hspi1;

// ── Pin mapping  (matches platformio.ini) ───────────────────
#define SX_NSS_PORT    GPIOA
#define SX_NSS_PIN     GPIO_PIN_4
#define SX_BUSY_PORT   GPIOA
#define SX_BUSY_PIN    GPIO_PIN_8
#define SX_RESET_PORT  GPIOB
#define SX_RESET_PIN   GPIO_PIN_1

// ── SX1280 Commands ─────────────────────────────────────────
#define SX_CMD_SET_STANDBY          0x80
#define SX_CMD_SET_PACKET_TYPE      0x8A
#define SX_CMD_SET_RF_FREQUENCY     0x86
#define SX_CMD_SET_TX_PARAMS        0x8E
#define SX_CMD_SET_BUFFER_BASE      0x98
#define SX_CMD_SET_MOD_PARAMS       0x8B
#define SX_CMD_SET_PKT_PARAMS       0x8C
#define SX_CMD_SET_DIO_IRQ_PARAMS   0x8D
#define SX_CMD_GET_IRQ_STATUS       0x15
#define SX_CMD_CLR_IRQ_STATUS       0x97
#define SX_CMD_WRITE_REGISTER       0x18
#define SX_CMD_WRITE_BUFFER         0x1A
#define SX_CMD_SET_TX               0x83

// ── Packet type ─────────────────────────────────────────────
#define SX_PACKET_TYPE_LORA   0x01

// ── LoRa Spreading Factor ────────────────────────────────────
#define LORA_SF5    0x50
#define LORA_SF6    0x60
#define LORA_SF7    0x70   // recommended default
#define LORA_SF8    0x80
#define LORA_SF9    0x90

// ── LoRa Bandwidth ──────────────────────────────────────────
#define LORA_BW_200   0x34
#define LORA_BW_400   0x26
#define LORA_BW_800   0x18   // recommended default
#define LORA_BW_1600  0x0A

// ── LoRa Coding Rate ────────────────────────────────────────
#define LORA_CR_4_5   0x01
#define LORA_CR_4_6   0x02
#define LORA_CR_4_7   0x03
#define LORA_CR_4_8   0x04

// ── IRQ mask bits ───────────────────────────────────────────
#define SX_IRQ_TX_DONE   0x0001
#define SX_IRQ_RX_DONE   0x0002
#define SX_IRQ_ALL       0xFFFF

// ── Ramp time ───────────────────────────────────────────────
#define SX_RAMP_20_US    0xE0

// ── LoRa sync word register addresses ───────────────────────
#define SX_REG_LORA_SYNC_MSB   0x0944
#define SX_REG_LORA_SYNC_LSB   0x0945

// ============================================================
//  Public API
// ============================================================
void     SX1280_WaitBusy(void);
void     SX1280_WriteCmd(uint8_t cmd, const uint8_t *data, uint8_t len);
void     SX1280_ReadCmd (uint8_t cmd, uint8_t *data, uint8_t len);
void     SX1280_WriteReg(uint16_t addr, const uint8_t *data, uint8_t len);
void     SX1280_WriteBuf(uint8_t offset, const uint8_t *data, uint8_t len);
void     SX1280_Reset   (void);

// High-level init: freq in Hz, power in dBm (-18 … +13)
void     SX1280_Init    (uint32_t freq_hz, int8_t power_dbm);

// Set LoRa sync word — write 0x1424 to be ELRS-compatible on RX side
void     SX1280_SetSyncWord(uint16_t sw);

uint16_t SX1280_GetIrq  (void);
void     SX1280_ClearIrq(uint16_t mask);

// Transmit len bytes.  Returns true when TxDone IRQ fires within timeout_ms.
bool     SX1280_Transmit(const uint8_t *data, uint8_t len, uint32_t timeout_ms);

void SX1280_SetRfFrequency(uint32_t freq_hz);
