#include "targets.h"

#include "CRSFConnector.h"
#include "../logging/logging.h"

void CRSFConnector::addDevice(const crsf_addr_e device_id)
{
    if (device_id != 0)
    {
        devices.insert(device_id);
    }
}

bool CRSFConnector::forwardsTo(const crsf_addr_e device_id)
{
    return devices.find(device_id) != devices.end();
}

void CRSFConnector::debugCRSF(const char *str, const crsf_header_t *message)
{
    DBGLN(str);
    DBGLN("dev:  %x", message->sync_byte);
    DBGLN("size: %x", message->frame_size);
    DBGLN("type: %x", message->type);
    if (message->type >= CRSF_FRAMETYPE_DEVICE_PING)
    {
        const auto ext = (crsf_ext_header_t *)message;
        DBGLN("dest: %x", ext->dest_addr);
        DBGLN("orig: %x", ext->orig_addr);
    }
}
