#pragma once

#include "targets.h"
#include <cmath>
#include <cstdint>

#include <cstddef>
#include <cstring>

#define PACKED __attribute__((packed))

#define CRSF_CRC_POLY 0xd5

#define CHANNEL_VALUE_FS_US_MIN         476  // stretch failsafe limit - changing this requires edits in getPwmFormData()
#define CHANNEL_VALUE_FS_US_ELIMITS_MIN 880  // ELimits failsafe min
#define CHANNEL_VALUE_FS_US_MID         1500 // center
#define CHANNEL_VALUE_FS_US_ELIMITS_MAX 2120 // Elimits failsafe max
#define CHANNEL_VALUE_FS_US_MAX         2523 // stretch failsafe limit

#define CRSF_CHANNEL_VALUE_EXT_MIN 0    // 880us with E.Limits on (-121.1%)
#define CRSF_CHANNEL_VALUE_MIN  172 // 987us - actual CRSF min is 0 with E.Limits on
#define CRSF_CHANNEL_VALUE_1000 191
#define CRSF_CHANNEL_VALUE_MID  992
#define CRSF_CHANNEL_VALUE_2000 1792
#define CRSF_CHANNEL_VALUE_MAX  1811 // 2012us - actual CRSF max is 1984 with E.Limits on
#define CRSF_CHANNEL_VALUE_EXT_MAX 1984 // 2120us with E.Limits on (+121.1%)
#define CRSF_CHANNEL_VALUE_UNSET 0xffff // used internally to indicate no channel value has been received

#define CRSF_MIN_PACKET_LEN 4
#define CRSF_MAX_PACKET_LEN 64

#define CRSF_SYNC_BYTE 0xC8

#define CRSF_PAYLOAD_SIZE_MAX 62
#define CRSF_FRAME_NOT_COUNTED_BYTES 2
#define CRSF_FRAME_SIZE(payload_size) ((payload_size) + 2) // See crsf_header_t.frame_size
#define CRSF_EXT_FRAME_SIZE(payload_size) (CRSF_FRAME_SIZE(payload_size) + 2)
#define CRSF_FRAME_SIZE_MAX (CRSF_PAYLOAD_SIZE_MAX + CRSF_FRAME_NOT_COUNTED_BYTES)
#define CRSF_FRAME_CRC_SIZE 1
#define CRSF_FRAME_LENGTH_EXT_TYPE_CRC 4 // length of Extended Dest/Origin, TYPE and CRC fields combined

#define CRSF_TELEMETRY_LENGTH_INDEX 1
#define CRSF_TELEMETRY_TYPE_INDEX 2
#define CRSF_TELEMETRY_FIELD_ID_INDEX 5
#define CRSF_TELEMETRY_FIELD_CHUNK_INDEX 6
#define CRSF_TELEMETRY_CRC_LENGTH 1
#define CRSF_TELEMETRY_TOTAL_SIZE(x) (x + CRSF_FRAME_LENGTH_EXT_TYPE_CRC)

//////////////////////////////////////////////////////////////

#define CRSF_MSP_REQ_PAYLOAD_SIZE 8
#define CRSF_MSP_RESP_PAYLOAD_SIZE 58
#define CRSF_MSP_MAX_PAYLOAD_SIZE (CRSF_MSP_REQ_PAYLOAD_SIZE > CRSF_MSP_RESP_PAYLOAD_SIZE ? CRSF_MSP_REQ_PAYLOAD_SIZE : CRSF_MSP_RESP_PAYLOAD_SIZE)

#define CRSF_VAL_MIN    172
#define CRSF_VAL_MID    992
#define CRSF_VAL_MAX    1811


typedef enum : uint8_t
{
    CRSF_FRAMETYPE_GPS = 0x02,
    CRSF_FRAMETYPE_VARIO = 0x07,
    CRSF_FRAMETYPE_BATTERY_SENSOR = 0x08,
    CRSF_FRAMETYPE_BARO_ALTITUDE = 0x09,
    CRSF_FRAMETYPE_AIRSPEED = 0x0A,
    CRSF_FRAMETYPE_HEARTBEAT = 0x0B,
    CRSF_FRAMETYPE_RPM = 0x0C,
    CRSF_FRAMETYPE_TEMP = 0x0D,
    CRSF_FRAMETYPE_CELLS = 0x0E,
    CRSF_FRAMETYPE_LINK_STATISTICS = 0x14,
    CRSF_FRAMETYPE_RC_CHANNELS_PACKED = 0x16,
    CRSF_FRAMETYPE_ATTITUDE = 0x1E,
    CRSF_FRAMETYPE_FLIGHT_MODE = 0x21,
    // Extended Header Frames, range: 0x28 to 0x96
    CRSF_FRAMETYPE_DEVICE_PING = 0x28,
    CRSF_FRAMETYPE_DEVICE_INFO = 0x29,
    CRSF_FRAMETYPE_PARAMETER_SETTINGS_ENTRY = 0x2B,
    CRSF_FRAMETYPE_PARAMETER_READ = 0x2C,
    CRSF_FRAMETYPE_PARAMETER_WRITE = 0x2D,
    CRSF_FRAMETYPE_ELRS_STATUS = 0x2E, // ELRS good/bad packet count and status flags

    CRSF_FRAMETYPE_COMMAND = 0x32,
    CRSF_FRAMETYPE_HANDSET = 0x3A,

    // KISS frames
    CRSF_FRAMETYPE_KISS_REQ  = 0x78,
    CRSF_FRAMETYPE_KISS_RESP = 0x79,
    // MSP commands
    CRSF_FRAMETYPE_MSP_REQ = 0x7A,   // response request using msp sequence as command
    CRSF_FRAMETYPE_MSP_RESP = 0x7B,  // reply with 58 byte chunked binary
    CRSF_FRAMETYPE_MSP_WRITE = 0x7C, // write with 8 byte chunked binary (OpenTX outbound telemetry buffer limit)
    // Ardupilot frames
    CRSF_FRAMETYPE_ARDUPILOT_RESP = 0x80,
} crsf_frame_type_e;

typedef enum : uint8_t {
    CRSF_COMMAND_SUBCMD_RX = 0x10
} crsf_command_e;

typedef enum : uint8_t {
    CRSF_COMMAND_SUBCMD_RX_BIND = 0x01,
    CRSF_COMMAND_MODEL_SELECT_ID = 0x05,
    CRSF_HANDSET_SUBCMD_TIMING = 0x10,
} crsf_subcommand_e;

enum {
    CRSF_FRAME_TX_MSP_FRAME_SIZE = 58,
    CRSF_FRAME_RX_MSP_FRAME_SIZE = 8,
    CRSF_FRAME_ORIGIN_DEST_SIZE = 2,
};

typedef enum : uint8_t
{
    CRSF_ADDRESS_BROADCAST = 0x00,
    CRSF_ADDRESS_USB = 0x10,
    CRSF_ADDRESS_BLUETOOTH_WIFI = 0x12,
    CRSF_ADDRESS_TBS_CORE_PNP_PRO = 0x80,
    CRSF_ADDRESS_RESERVED1 = 0x8A,
    CRSF_ADDRESS_CURRENT_SENSOR = 0xC0,
    CRSF_ADDRESS_GPS = 0xC2,
    CRSF_ADDRESS_TBS_BLACKBOX = 0xC4,
    CRSF_ADDRESS_FLIGHT_CONTROLLER = 0xC8,
    CRSF_ADDRESS_RESERVED2 = 0xCA,
    CRSF_ADDRESS_RACE_TAG = 0xCC,
    CRSF_ADDRESS_RADIO_TRANSMITTER = 0xEA,
    CRSF_ADDRESS_CRSF_RECEIVER = 0xEC,
    CRSF_ADDRESS_CRSF_TRANSMITTER = 0xEE,
    CRSF_ADDRESS_ELRS_LUA = 0xEF
} crsf_addr_e;

//typedef struct crsf_addr_e asas;

typedef enum : uint8_t
{
    CRSF_UINT8 = 0,
    CRSF_INT8 = 1,
    CRSF_UINT16 = 2,
    CRSF_INT16 = 3,
    CRSF_UINT32 = 4,
    CRSF_INT32 = 5,
    CRSF_UINT64 = 6,
    CRSF_INT64 = 7,
    CRSF_FLOAT = 8,
    CRSF_TEXT_SELECTION = 9,
    CRSF_STRING = 10,
    CRSF_FOLDER = 11,
    CRSF_INFO = 12,
    CRSF_COMMAND = 13,
    CRSF_VTX = 15,
    CRSF_OUT_OF_RANGE = 127,
} crsf_value_type_e;

// These flags are or'ed with the field type above to hide the field from the normal LUA view
#define CRSF_FIELD_HIDDEN       0x80     // marked as hidden in all LUA responses
#define CRSF_FIELD_ELRS_HIDDEN  0x40     // marked as hidden when talking to ELRS specific LUA
#define CRSF_FIELD_TYPE_MASK    ~(CRSF_FIELD_HIDDEN|CRSF_FIELD_ELRS_HIDDEN)

/**
 * Define the shape of a standard header
 */
typedef struct crsf_header_s
{
    uint8_t sync_byte;
    uint8_t frame_size;  // counts size after this byte, so it must be the payload size + 2 (type and crc)
    crsf_frame_type_e type;
    uint8_t payload[0];
} PACKED crsf_header_t;

#define CRSF_MK_FRAME_T(payload) struct payload##_frame_s { crsf_header_t h; payload p; uint8_t crc; } PACKED
#define CRSF_MK_EXT_FRAME_T(payload) struct payload##_frame_s { crsf_ext_header_t h; payload p; uint8_t crc; } PACKED

// Used by extended header frames (type in range 0x28 to 0x96)
typedef struct crsf_ext_header_s
{
    // Common header fields, see crsf_header_t
    uint8_t device_addr;
    uint8_t frame_size;
    crsf_frame_type_e type;
    // Extended fields
    crsf_addr_e dest_addr;
    crsf_addr_e orig_addr;
    uint8_t payload[0];
} PACKED crsf_ext_header_t;

/**
 * Crossfire packed channel structure, each channel is 11 bits
 */
typedef struct crsf_channels_s
{
    unsigned ch0 : 11;
    unsigned ch1 : 11;
    unsigned ch2 : 11;
    unsigned ch3 : 11;
    unsigned ch4 : 11;
    unsigned ch5 : 11;
    unsigned ch6 : 11;
    unsigned ch7 : 11;
    unsigned ch8 : 11;
    unsigned ch9 : 11;
    unsigned ch10 : 11;
    unsigned ch11 : 11;
    unsigned ch12 : 11;
    unsigned ch13 : 11;
    unsigned ch14 : 11;
    unsigned ch15 : 11;
} PACKED crsf_channels_t;

static inline void crsf_unpack_channels(const uint8_t *p, uint32_t *out) 
{
    // Each channel is 11 bits, packed LSB-first across bytes.
    // Explicit extraction is compiler-independent and deterministic.
    out[0]  = ((uint32_t)p[0]        | (uint32_t)p[1]  << 8) & 0x7FF;
    out[1]  = ((uint32_t)p[1]  >> 3  | (uint32_t)p[2]  << 5) & 0x7FF;
    out[2]  = ((uint32_t)p[2]  >> 6  | (uint32_t)p[3]  << 2
                                      | (uint32_t)p[4]  << 10) & 0x7FF;
    out[3]  = ((uint32_t)p[4]  >> 1  | (uint32_t)p[5]  << 7) & 0x7FF;
    out[4]  = ((uint32_t)p[5]  >> 4  | (uint32_t)p[6]  << 4) & 0x7FF;
    out[5]  = ((uint32_t)p[6]  >> 7  | (uint32_t)p[7]  << 1
                                      | (uint32_t)p[8]  << 9) & 0x7FF;
    out[6]  = ((uint32_t)p[8]  >> 2  | (uint32_t)p[9]  << 6) & 0x7FF;
    out[7]  = ((uint32_t)p[9]  >> 5  | (uint32_t)p[10] << 3) & 0x7FF;
    out[8]  = ((uint32_t)p[11]       | (uint32_t)p[12] << 8) & 0x7FF;
    out[9]  = ((uint32_t)p[12] >> 3  | (uint32_t)p[13] << 5) & 0x7FF;
    out[10] = ((uint32_t)p[13] >> 6  | (uint32_t)p[14] << 2
                                      | (uint32_t)p[15] << 10) & 0x7FF;
    out[11] = ((uint32_t)p[15] >> 1  | (uint32_t)p[16] << 7) & 0x7FF;
    out[12] = ((uint32_t)p[16] >> 4  | (uint32_t)p[17] << 4) & 0x7FF;
    out[13] = ((uint32_t)p[17] >> 7  | (uint32_t)p[18] << 1
                                      | (uint32_t)p[19] << 9) & 0x7FF;
    out[14] = ((uint32_t)p[19] >> 2  | (uint32_t)p[20] << 6) & 0x7FF;
    out[15] = ((uint32_t)p[20] >> 5  | (uint32_t)p[21] << 3) & 0x7FF;
}

static inline uint8_t crsf_crc8(const uint8_t *data, uint8_t len) {
    uint8_t crc = 0;
    for (uint8_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (uint8_t j = 0; j < 8; j++) {
            crc = (crc & 0x80) ? (crc << 1) ^ 0xD5 : (crc << 1);
        }
    }
    return crc;
}

static inline uint32_t crsf_to_us(uint32_t raw) 
{
    // Scaled: ((raw - 992) * 5 / 8) + 1500
    // Multiply first to preserve precision before divide.
    return (uint32_t)(((int32_t)(raw - CRSF_VAL_MID) * 5) / 8 + 1500);
}


/**
 * Bits used in the byte following crsf_channels_t in the ExpressLRS extended CHANNELS_PACKED packet
 */
#define CRSF_CHANNELS_STATUS_ARMED              bit(0)    // Armed status in Arm using Switch mode
#define CRSF_CHANNELS_STATUS_ARMING_MODE_CH5    bit(1)    // Arm using CH5 if bit is set

typedef struct deviceInformationPacket_s
{
    uint32_t serialNo;
    uint32_t hardwareVer;
    uint32_t softwareVer;
    uint8_t fieldCnt;          //number of field of params this device has
    uint8_t parameterVersion;
} PACKED deviceInformationPacket_t;

static inline size_t get_device_information_payload_length(const char* device_name) {
    return sizeof(deviceInformationPacket_t) + strlen(device_name) + 1;
}

static inline size_t get_device_information_length(const char* device_name) {
    return sizeof(crsf_ext_header_t) + get_device_information_payload_length(device_name) + CRSF_FRAME_CRC_SIZE;
}

static inline size_t get_device_information_frame_size(const char* device_name) {
    return get_device_information_payload_length(device_name) + CRSF_FRAME_LENGTH_EXT_TYPE_CRC;
}

typedef struct crsf_sync_packet_s {
    uint8_t subType;
    uint32_t rate; // Big-Endian
    uint32_t offset; // Big-Endian
} PACKED crsf_sync_packet_t;

// https://github.com/betaflight/betaflight/blob/master/src/main/msp/msp.c#L1949
typedef struct mspVtxConfigPacket_s
{
    uint8_t vtxType;
    uint8_t band;
    uint8_t channel;
    uint8_t power;
    uint8_t pitmode;
    uint16_t freq;
    uint8_t deviceIsReady;
    uint8_t lowPowerDisarm;
    uint16_t pitModeFreq;
    uint8_t vtxTableAvailable;
    uint8_t bands;
    uint8_t channels;
    uint8_t powerLevels;
} PACKED mspVtxConfigPacket_t;

typedef struct mspVtxPowerLevelPacket_s
{
    uint8_t powerLevel;
    uint16_t powerValue;
    uint8_t powerLabelLength;
    uint8_t label[3];
} PACKED mspVtxPowerLevelPacket_t;

typedef struct mspVtxBandPacket_s
{
    uint8_t band;
    uint8_t bandNameLength;
    uint8_t bandName[8];
    uint8_t bandLetter;
    uint8_t isFactoryBand;
    uint8_t channels;
    uint16_t channel[8];
} PACKED mspVtxBandPacket_t;

#define MSP_REQUEST_PAYLOAD_LENGTH(len) 7 + len // status + flags + 2 function + 2 length + crc + payload
#define MSP_REQUEST_LENGTH(len) (sizeof(crsf_ext_header_t) + MSP_REQUEST_PAYLOAD_LENGTH(len) + CRSF_FRAME_CRC_SIZE)
#define MSP_REQUEST_FRAME_SIZE(len) (MSP_REQUEST_PAYLOAD_LENGTH(len) + CRSF_FRAME_LENGTH_EXT_TYPE_CRC)

#define MSP_SET_VTX_CONFIG_PAYLOAD_LENGTH 15
#define MSP_SET_VTXTABLE_BAND_PAYLOAD_LENGTH 29
#define MSP_SET_VTXTABLE_POWERLEVEL_PAYLOAD_LENGTH 7

//CRSF_FRAMETYPE_BATTERY_SENSOR
typedef struct crsf_sensor_battery_s
{
    unsigned voltage : 16;  // mv * 100 BigEndian
    unsigned current : 16;  // ma * 100
    unsigned capacity : 24; // mah
    unsigned remaining : 8; // %
} PACKED crsf_sensor_battery_t;

// CRSF_FRAMETYPE_BARO_ALTITUDE
typedef struct crsf_sensor_baro_vario_s
{
    uint16_t altitude; // Altitude in decimeters + 10000dm, or Altitude in meters if high bit is set, BigEndian
    int16_t verticalspd;  // Vertical speed in cm/s, BigEndian
} PACKED crsf_sensor_baro_vario_t;

// CRSF_FRAMETYPE_AIRSPEED
typedef struct crsf_sensor_airspeed_s
{
    uint16_t speed;             // Airspeed in 0.1 * km/h (hectometers/h)
} PACKED crsf_sensor_airspeed_t;

// CRSF_FRAMETYPE_RPM
typedef struct crsf_sensor_rpm_s
{
    uint8_t source_id;          // Identifies the source of the RPM data (e.g., 0 = Motor 1, 1 = Motor 2, etc.)
    int32_t rpm0:24;            // 1 - 19 RPM values with negative ones representing the motor spinning in reverse
    int32_t rpm1:24;
    int32_t rpm2:24;
    int32_t rpm3:24;
    int32_t rpm4:24;
    int32_t rpm5:24;
    int32_t rpm6:24;
    int32_t rpm7:24;
    int32_t rpm8:24;
    int32_t rpm9:24;
    int32_t rpm10:24;
    int32_t rpm11:24;
    int32_t rpm12:24;
    int32_t rpm13:24;
    int32_t rpm14:24;
    int32_t rpm15:24;
    int32_t rpm16:24;
    int32_t rpm17:24;
    int32_t rpm18:24;
} PACKED crsf_sensor_rpm_t;

// CRSF_FRAMETYPE_TEMP
typedef struct crsf_sensor_temp_s
{
    uint8_t source_id;            // Identifies the source of the temperature data (e.g., 0 = FC including all ESCs, 1 = Ambient, etc.)
    int16_t temperature[20];      // up to 20 temperature values in deci-degree (tenths of a degree) Celsius (e.g., 250 = 25.0°C, -50 = -5.0°C)
} PACKED crsf_sensor_temp_t;

// CRSF_FRAMETYPE_CELLS
typedef struct crsf_sensor_cells_s
{
    uint8_t source_id;            // Identifies the source of the Main_battery data (e.g., 0 = battery 1, 1 = battery 2, etc.)
    uint16_t cell[29];            // up to 29 cell values in a resolution of a thousandth of a Volt (e.g. 3.850V = 3850)
} PACKED crsf_sensor_cells_t;

// CRSF_FRAMETYPE_VARIO
typedef struct crsf_sensor_vario_s
{
    int16_t verticalspd;  // Vertical speed in cm/s, BigEndian
} PACKED crsf_sensor_vario_t;

// CRSF_FRAMETYPE_GPS
typedef struct crsf_sensor_gps_s
{
    int32_t latitude; // degree / 10`000`000
    int32_t longitude; // degree / 10`000`000
    uint16_t groundspeed; // km/h / 10
    uint16_t gps_heading; // degree / 100
    uint16_t altitude; // meter ­1000m offset
    uint8_t satellites_in_use; // counter
} PACKED crsf_sensor_gps_t;

// CRSF_FRAMETYPE_ATTITUDE
typedef struct crsf_sensor_attitude_s
{
    int16_t pitch; // radians * 10000
    int16_t roll; // radians * 10000
    int16_t yaw; // radians * 10000
} PACKED crsf_sensor_attitude_t;

// CRSF_FRAMETYPE_FLIGHT_MODE
typedef struct crsf_sensor_flight_mode_s
{
    char flight_mode[16];
} PACKED crsf_flight_mode_t;

/*
 * 0x14 Link statistics
 * Payload:
 *
 * uint8_t Uplink RSSI Ant. 1 ( dBm * -1 )
 * uint8_t Uplink RSSI Ant. 2 ( dBm * -1 )
 * uint8_t Uplink Package success rate / Link quality ( % )
 * int8_t Uplink SNR ( db )
 * uint8_t Diversity active antenna ( enum ant. 1 = 0, ant. 2 )
 * uint8_t RF Mode ( enum 4fps = 0 , 50fps, 150hz)
 * uint8_t Uplink TX Power ( enum 0mW = 0, 10mW, 25 mW, 100 mW, 500 mW, 1000 mW, 2000mW )
 * uint8_t Downlink RSSI ( dBm * -1 )
 * uint8_t Downlink package success rate / Link quality ( % )
 * int8_t Downlink SNR ( db )
 * Uplink is the connection from the ground to the UAV and downlink the opposite direction.
 */

typedef struct crsfPayloadLinkstatistics_s
{
    uint8_t uplink_RSSI_1;
    uint8_t uplink_RSSI_2;
    uint8_t uplink_Link_quality;
    int8_t uplink_SNR;
    uint8_t active_antenna;
    uint8_t rf_Mode;
    uint8_t uplink_TX_Power;
    uint8_t downlink_RSSI_1;
    uint8_t downlink_Link_quality;
    int8_t downlink_SNR;
} PACKED crsfLinkStatistics_t;

typedef struct elrsLinkStatistics_s : crsfLinkStatistics_t
{
    uint8_t downlink_RSSI_2;
} PACKED elrsLinkStatistics_t;

/////inline and utility functions//////

static uint16_t ICACHE_RAM_ATTR fmap(uint16_t x, uint16_t in_min, uint16_t in_max, uint16_t out_min, uint16_t out_max)
{
    int32_t result = ((int32_t)(x - in_min) * (out_max - out_min) * 2 / (in_max - in_min) + out_min * 2 + 1)/2;
    return result < 0 ? 0 : (result > 65535 ? 65535 : result);
}

// Scale a -100& to +100% crossfire value to 988-2012 (Taranis channel uS)
static inline uint16_t ICACHE_RAM_ATTR CRSF_to_US(uint16_t val)
{
    return fmap(val, CRSF_CHANNEL_VALUE_MIN, CRSF_CHANNEL_VALUE_MAX, 988, 2012);
}

// Scale down a 10-bit value to a -100& to +100% crossfire value
static inline uint16_t ICACHE_RAM_ATTR UINT10_to_CRSF(uint16_t val)
{
    return fmap(val, 0, 1023, CRSF_CHANNEL_VALUE_MIN, CRSF_CHANNEL_VALUE_MAX);
}

// Scale up a -100& to +100% crossfire value to 10-bit
static inline uint16_t ICACHE_RAM_ATTR CRSF_to_UINT10(uint16_t val)
{
    return fmap(val, CRSF_CHANNEL_VALUE_MIN, CRSF_CHANNEL_VALUE_MAX, 0, 1023);
}

// Convert 0-max to the CRSF values for 1000-2000
static inline uint16_t ICACHE_RAM_ATTR N_to_CRSF(uint16_t val, uint16_t max)
{
    return val * (CRSF_CHANNEL_VALUE_2000-CRSF_CHANNEL_VALUE_1000) / max + CRSF_CHANNEL_VALUE_1000;
}

// Convert CRSF to 0-(cnt-1), constrained between 1000us and 2000us
static inline uint16_t ICACHE_RAM_ATTR CRSF_to_N(uint16_t val, uint16_t cnt)
{
    // The span is increased by one to prevent the max val from returning cnt
    if (val <= CRSF_CHANNEL_VALUE_1000)
        return 0;
    if (val >= CRSF_CHANNEL_VALUE_2000)
        return cnt - 1;
    return (val - CRSF_CHANNEL_VALUE_1000) * cnt / (CRSF_CHANNEL_VALUE_2000 - CRSF_CHANNEL_VALUE_1000 + 1);
}

static inline uint8_t ICACHE_RAM_ATTR CRSF_to_SWITCH3b(uint16_t ch)
{
    // AUX2-7 are Low Resolution, "7pos" 6+center (3-bit)
    // The output is mapped evenly across 6 output values (0-5)
    // with a special value 7 indicating the middle so it works
    // with switches with a middle position as well as 6-position
    const uint16_t CHANNEL_BIN_COUNT = 6;
    const uint16_t CHANNEL_BIN_SIZE = (CRSF_CHANNEL_VALUE_MAX - CRSF_CHANNEL_VALUE_MIN) / CHANNEL_BIN_COUNT;
    // If channel is within 1/4 a BIN of being in the middle use special value 7
    if (ch < (CRSF_CHANNEL_VALUE_MID-CHANNEL_BIN_SIZE/4)
        || ch > (CRSF_CHANNEL_VALUE_MID+CHANNEL_BIN_SIZE/4))
        return CRSF_to_N(ch, CHANNEL_BIN_COUNT);
    return 7;
}

// 3b switches use 0-5 to represent 6 positions switches and "7" to represent middle
// The calculation is a bit non-linear all the way to the endpoints due to where
// Ardupilot defines its modes
static inline uint16_t ICACHE_RAM_ATTR SWITCH3b_to_CRSF(uint16_t val)
{
    switch (val)
    {
    case 0: return CRSF_CHANNEL_VALUE_1000;
    case 5: return CRSF_CHANNEL_VALUE_2000;
    case 6: // fallthrough
    case 7: return CRSF_CHANNEL_VALUE_MID;
    default: // (val - 1) * 240 + 630; aka 150us spacing, starting at 1275
        return val * 240 + 391;
    }
}

// Returns 1 if val is greater than CRSF_CHANNEL_VALUE_MID
static inline uint8_t ICACHE_RAM_ATTR CRSF_to_BIT(uint16_t val)
{
    return (val > CRSF_CHANNEL_VALUE_MID) ? 1 : 0;
}

// Convert a bit into either the CRSF value for 1000 or 2000
static inline uint16_t ICACHE_RAM_ATTR BIT_to_CRSF(uint8_t val)
{
    return (val) ? CRSF_CHANNEL_VALUE_2000 : CRSF_CHANNEL_VALUE_1000;
}

static inline uint8_t ICACHE_RAM_ATTR CalcCRCMsp(uint8_t *data, int length)
{
    uint8_t crc = 0;
    for (uint8_t i = 0; i < length; ++i) {
        crc = crc ^ *data++;
    }
    return crc;
}

#if !defined(__linux__)
static inline uint16_t htobe16(uint16_t val)
{
#if (__BYTE_ORDER__ == __ORDER_BIG_ENDIAN__)
    return val;
#else
    return __builtin_bswap16(val);
#endif
}

static inline uint16_t be16toh(uint16_t val)
{
#if (__BYTE_ORDER__ == __ORDER_BIG_ENDIAN__)
    return val;
#else
    return __builtin_bswap16(val);
#endif
}

static inline uint32_t htobe32(uint32_t val)
{
#if (__BYTE_ORDER__ == __ORDER_BIG_ENDIAN__)
    return val;
#else
    return __builtin_bswap32(val);
#endif
}

static inline uint32_t be32toh(uint32_t val)
{
#if (__BYTE_ORDER__ == __ORDER_BIG_ENDIAN__)
    return val;
#else
    return __builtin_bswap32(val);
#endif
}
#endif
