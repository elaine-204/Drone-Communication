#include "POWERMGNT.h"
#include "logging.h"
#include "targets.h"
#include "CRSFRouter.h"
#include "common.h"
#include "device.h"
#include "helpers.h"
#include "SX1280Driver.h"  

#if defined(RADIO_SX128X)
extern SX1280Driver Radio;
#endif


// --- STM32 DIY Power Table ---
// Renamed to avoid macro collision
static const int8_t STM32_PWR_VALUES[] = {
    -18, // 10mW
    -6,  // 25mW
    -3,  // 50mW
    0,   // 100mW
    3,   // 250mW
    3,   // 500mW (capped)
    3,   // 1000mW (capped)
    3    // 2000mW (capped)
};
static const int STM32_PWR_COUNT = sizeof(STM32_PWR_VALUES)/sizeof(STM32_PWR_VALUES[0]);

uint8_t powerToCrsfPower(PowerLevels_e Power)
{
    switch (Power)
    {
    case PWR_10mW: return 1;
    case PWR_25mW: return 2;
    case PWR_50mW: return 8;
    case PWR_100mW: return 3;
    case PWR_250mW: return 7;
    case PWR_500mW: return 4;
    case PWR_1000mW: return 5;
    case PWR_2000mW: return 6;
    default: return 0;
    }
}

PowerLevels_e crsfPowerToPower(uint8_t crsfpower)
{
    switch (crsfpower)
    {
    case 1: return PWR_10mW;
    case 2: return PWR_25mW;
    case 3: return PWR_100mW;
    case 4: return PWR_500mW;
    case 5: return PWR_1000mW;
    case 6: return PWR_2000mW;
    case 7: return PWR_250mW;
    case 8: return PWR_50mW;
    default: return PWR_10mW;
    }
}

#ifndef UNIT_TEST

PowerLevels_e PowerLevelContainer::CurrentPower = PWR_COUNT;
PowerLevels_e POWERMGNT::FanEnableThreshold = PWR_250mW;
int8_t POWERMGNT::CurrentSX1280Power = 0;

extern bool isUsingPrimaryFreqBand();
static int8_t powerCaliValues[PWR_COUNT] = {0};

// Updated macro to use our specific table size
#define SAFE_GET_POWER_VALUE(values, idx) (((idx) < (STM32_PWR_COUNT)) ? (values)[idx] : (values)[0])

PowerLevels_e POWERMGNT::incPower()
{
    if (CurrentPower < getMaxPower())
    {
        setPower((PowerLevels_e)((uint8_t)CurrentPower + 1));
    }
    return CurrentPower;
}

PowerLevels_e POWERMGNT::decPower()
{
    if (CurrentPower > MinPower)
    {
        setPower((PowerLevels_e)((uint8_t)CurrentPower - 1));
    }
    return CurrentPower;
}

void POWERMGNT::incSX1280Output()
{
    if (CurrentSX1280Power < 13)
    {
        CurrentSX1280Power++;
        Radio.SetOutputPower(CurrentSX1280Power);
    }
}

void POWERMGNT::decSX1280Output()
{
    if (CurrentSX1280Power > -18)
    {
        CurrentSX1280Power--;
        Radio.SetOutputPower(CurrentSX1280Power);
    }
}

int8_t POWERMGNT::currentSX1280Output()
{
    return CurrentSX1280Power;
}

uint8_t POWERMGNT::getPowerIndBm()
{
    switch (CurrentPower)
    {
    case PWR_10mW: return 10;
    case PWR_25mW: return 14;
    case PWR_50mW: return 17;
    case PWR_100mW: return 20;
    case PWR_250mW: return 24;
    case PWR_500mW: return 27;
    case PWR_1000mW: return 30;
    case PWR_2000mW: return 33;
    default: return 0;
    }
}

void POWERMGNT::SetPowerCaliValues(int8_t *values, size_t size)
{
    UNUSED(values);
    UNUSED(size);
}

void POWERMGNT::GetPowerCaliValues(int8_t *values, size_t size)
{
    for(size_t i=0 ; i<size ; i++)
    {
        *(values + i) = powerCaliValues[i];
    }
}

void POWERMGNT::LoadCalibration()
{
    memset(powerCaliValues, 0, sizeof(powerCaliValues));
}

void POWERMGNT::init()
{
    PowerLevelContainer::CurrentPower = PWR_COUNT;
    LoadCalibration();
    setDefaultPower();
}

PowerLevels_e POWERMGNT::getDefaultPower()
{
    if (MinPower > DefaultPower) return MinPower;
    if (getMaxPower() < DefaultPower) return getMaxPower();
    return DefaultPower;
}

void POWERMGNT::setDefaultPower()
{
    setPower(getDefaultPower());
}

void POWERMGNT::setPower(PowerLevels_e Power)
{
    Power = constrain(Power, getMinPower(), getMaxPower());
    if (Power == CurrentPower) return;

    CurrentPower = Power;
    const uint8_t powerIdx = Power - getMinPower();

    // Use our local array STM32_PWR_VALUES
    CurrentSX1280Power = SAFE_GET_POWER_VALUE(STM32_PWR_VALUES, powerIdx) + powerCaliValues[Power];
    Radio.SetOutputPower(CurrentSX1280Power);

    CurrentPower = Power;
    linkStats.uplink_TX_Power = powerToCrsfPower(PowerLevelContainer::currPower());
    devicesTriggerEvent(EVENT_POWER_CHANGED);
}

#endif /* !UNIT_TEST */