#include "TXModuleEndpoint.h"

#include "rxtx_intf.h"
#include "CRSFHandset.h"
#include "CRSFRouter.h"
#include "FHSS.h"
#include "OTA.h"
#include "POWERMGNT.h"
#include "config.h"
#include "helpers.h"
#include "deferred.h"
#include "msptypes.h"


#define STR_LUA_ALLAUX         "AUX1;AUX2;AUX3;AUX4;AUX5;AUX6;AUX7;AUX8;AUX9;AUX10"

#define STR_LUA_ALLAUX_UPDOWN  "AUX1" LUASYM_ARROW_UP ";AUX1" LUASYM_ARROW_DN ";AUX2" LUASYM_ARROW_UP ";AUX2" LUASYM_ARROW_DN \
                               ";AUX3" LUASYM_ARROW_UP ";AUX3" LUASYM_ARROW_DN ";AUX4" LUASYM_ARROW_UP ";AUX4" LUASYM_ARROW_DN \
                               ";AUX5" LUASYM_ARROW_UP ";AUX5" LUASYM_ARROW_DN ";AUX6" LUASYM_ARROW_UP ";AUX6" LUASYM_ARROW_DN \
                               ";AUX7" LUASYM_ARROW_UP ";AUX7" LUASYM_ARROW_DN ";AUX8" LUASYM_ARROW_UP ";AUX8" LUASYM_ARROW_DN \
                               ";AUX9" LUASYM_ARROW_UP ";AUX9" LUASYM_ARROW_DN ";AUX10" LUASYM_ARROW_UP ";AUX10" LUASYM_ARROW_DN


#if defined(RADIO_SX128X)
#define STR_LUA_PACKETRATES \
    "50Hz(-115dBm);100Hz Full(-112dBm);150Hz(-112dBm);250Hz(-108dBm);333Hz Full(-105dBm);500Hz(-105dBm);" \
    "D250(-104dBm);D500(-104dBm);F500(-104dBm);F1000(-104dBm)"
#else
#define STR_LUA_PACKETRATES ""
#endif

#define HAS_RADIO (GPIO_PIN_SCK != UNDEF_PIN)

extern char backpackVersion[];

// STM32 usually doesn't have regulatory limits hardcoded like this, but keeping logic just in case
char strPowerLevels[] = "10;25;50;100;250;500;1000;2000;MatchTX ";

static char version_domain[20+1+6+1];
static char pwrFolderDynamicName[] = "TX Power (1000 Dynamic)";
static char vtxFolderDynamicName[] = "VTX Admin (OFF:C:1 Aux11 )";
static char modelMatchUnit[] = " (ID: 00)";
static char tlmBandwidth[] = " (xxxxxbps)";
static constexpr char folderNameSeparator[2] = {' ',':'};
static constexpr char tlmRatios[] = "Std;Off;1:128;1:64;1:32;1:16;1:8;1:4;1:2;Race";
static constexpr char tlmRatiosMav[] = ";;;;;;;;1:2;";
static constexpr char switchmodeOpts4ch[] = "Wide;Hybrid";
static constexpr char switchmodeOpts4chMav[] = ";Hybrid";
static constexpr char switchmodeOpts8ch[] = "8ch;16ch Rate/2;12ch Mixed";
static constexpr char switchmodeOpts8chMav[] = ";16ch Rate/2;";
static constexpr char antennamodeOpts[] = "Gemini;Ant 1;Ant 2;Switch";
static constexpr char antennamodeOptsDualBand[] = "Gemini;;;";
static constexpr char linkModeOpts[] = "Normal;MAVLink";
static constexpr char luastrDvrAux[] = "Off;" STR_LUA_ALLAUX_UPDOWN;
static constexpr char luastrDvrDelay[] = "0s;5s;15s;30s;45s;1min;2min";
static constexpr char luastrHeadTrackingEnable[] = "Off;On;" STR_LUA_ALLAUX_UPDOWN;
static constexpr char luastrHeadTrackingStart[] = "EdgeTX;" STR_LUA_ALLAUX;
static constexpr char luastrOffOn[] = "Off;On";
static char luastrPacketRates[] = STR_LUA_PACKETRATES;

static selectionParameter luaAirRate = {
    {"Packet Rate", CRSF_TEXT_SELECTION},
    0, // value
    luastrPacketRates,
    STR_EMPTYSPACE
};

static selectionParameter luaTlmRate = {
    {"Telem Ratio", CRSF_TEXT_SELECTION},
    0, // value
    tlmRatios,
    tlmBandwidth
};

// --- Helper for STM32 Compatibility ---
static const char *strchrnul_local(const char *s, int c_in)
{
    char c = (char)c_in;
    while (*s && (*s != c))
    {
        s++;
    }
    return s;
}
// --------------------------------------


//----------------------------POWER------------------
static folderParameter luaPowerFolder = {
    {"TX Power", CRSF_FOLDER},pwrFolderDynamicName
};

static selectionParameter luaPower = {
    {"Max Power", CRSF_TEXT_SELECTION},
    0, // value
    strPowerLevels,
    "mW"
};

static selectionParameter luaDynamicPower = {
    {"Dynamic", CRSF_TEXT_SELECTION},
    0, // value
    "Off;Dyn;AUX9;AUX10;AUX11;AUX12",
    STR_EMPTYSPACE
};

static selectionParameter luaFanThreshold = {
    {"Fan Thresh", CRSF_TEXT_SELECTION},
    0, // value
    "10mW;25mW;50mW;100mW;250mW;500mW;1000mW;2000mW;Never",
    STR_EMPTYSPACE // units embedded so it won't display "NevermW"
};

//----------------------------POWER------------------

static selectionParameter luaSwitch = {
    {"Switch Mode", CRSF_TEXT_SELECTION},
    0, // value
    switchmodeOpts4ch,
    STR_EMPTYSPACE
};

static selectionParameter luaAntenna = {
    {"Antenna Mode", CRSF_TEXT_SELECTION},
    0, // value
    antennamodeOpts,
    STR_EMPTYSPACE
};

static selectionParameter luaLinkMode = {
    {"Link Mode", CRSF_TEXT_SELECTION},
    0, // value
    linkModeOpts,
    STR_EMPTYSPACE
};

static selectionParameter luaModelMatch = {
    {"Model Match", CRSF_TEXT_SELECTION},
    0, // value
    luastrOffOn,
    modelMatchUnit
};

static commandParameter luaBind = {
    {"Bind", CRSF_COMMAND},
    lcsIdle, // step
    STR_EMPTYSPACE
};

static stringParameter luaInfo = {
    {"Bad/Good", (crsf_value_type_e)(CRSF_INFO | CRSF_FIELD_ELRS_HIDDEN)},
    STR_EMPTYSPACE
};

static stringParameter luaELRSversion = {
    {version_domain, CRSF_INFO},
    commit
};

//---------------------------- WiFi -----------------------------
static folderParameter luaWiFiFolder = {
    {"WiFi Connectivity", CRSF_FOLDER}
};

static commandParameter luaWebUpdate = {
    {"Enable WiFi", CRSF_COMMAND},
    lcsIdle, // step
    STR_EMPTYSPACE
};

static commandParameter luaRxWebUpdate = {
    {"Enable Rx WiFi", CRSF_COMMAND},
    lcsIdle, // step
    STR_EMPTYSPACE
};

static commandParameter luaTxBackpackUpdate = {
    {"Enable Backpack WiFi", CRSF_COMMAND},
    lcsIdle, // step
    STR_EMPTYSPACE
};

static commandParameter luaVRxBackpackUpdate = {
    {"Enable VRx WiFi", CRSF_COMMAND},
    lcsIdle, // step
    STR_EMPTYSPACE
};
//---------------------------- WiFi -----------------------------

//----------------------------VTX ADMINISTRATOR------------------
static folderParameter luaVtxFolder = {
    {"VTX Administrator", CRSF_FOLDER},vtxFolderDynamicName
};

static selectionParameter luaVtxBand = {
    {"Band", CRSF_TEXT_SELECTION},
    0, // value
    "Off;A;B;E;F;R;L",
    STR_EMPTYSPACE
};

static int8Parameter luaVtxChannel = {
    {"Channel", CRSF_UINT8},
    0, // value
    1, // min
    8, // max
    STR_EMPTYSPACE
};

static selectionParameter luaVtxPwr = {
    {"Pwr Lvl", CRSF_TEXT_SELECTION},
    0, // value
    "-;1;2;3;4;5;6;7;8",
    STR_EMPTYSPACE
};

static selectionParameter luaVtxPit = {
    {"Pitmode", CRSF_TEXT_SELECTION},
    0, // value
    "Off;On;" STR_LUA_ALLAUX_UPDOWN,
    STR_EMPTYSPACE
};

static commandParameter luaVtxSend = {
    {"Send VTx", CRSF_COMMAND},
    lcsIdle, // step
    STR_EMPTYSPACE
};
//----------------------------VTX ADMINISTRATOR------------------

//---------------------------- BACKPACK ------------------
static folderParameter luaBackpackFolder = {
    {"Backpack", CRSF_FOLDER},
};

static selectionParameter luaBackpackEnable = {
    {"Backpack", CRSF_TEXT_SELECTION},
    0, // value
    luastrOffOn,
    STR_EMPTYSPACE};

static selectionParameter luaDvrAux = {
    {"DVR Rec", CRSF_TEXT_SELECTION},
    0, // value
    luastrDvrAux,
    STR_EMPTYSPACE};

static selectionParameter luaDvrStartDelay = {
    {"DVR Srt Dly", CRSF_TEXT_SELECTION},
    0, // value
    luastrDvrDelay,
    STR_EMPTYSPACE};

static selectionParameter luaDvrStopDelay = {
    {"DVR Stp Dly", CRSF_TEXT_SELECTION},
    0, // value
    luastrDvrDelay,
    STR_EMPTYSPACE};

static selectionParameter luaHeadTrackingEnableChannel = {
    {"HT Enable", CRSF_TEXT_SELECTION},
    0, // value
    luastrHeadTrackingEnable,
    STR_EMPTYSPACE};

static selectionParameter luaHeadTrackingStartChannel = {
    {"HT Start Channel", CRSF_TEXT_SELECTION},
    0, // value
    luastrHeadTrackingStart,
    STR_EMPTYSPACE};

static selectionParameter luaBackpackTelemetry = {
    {"Telemetry", CRSF_TEXT_SELECTION},
    0, // value
    "Off;ESPNOW;WiFi",
    STR_EMPTYSPACE};

static stringParameter luaBackpackVersion = {
    {"Version", CRSF_INFO},
    backpackVersion};

//---------------------------- BACKPACK ------------------

extern TxConfig config;
extern void VtxTriggerSend();
extern void ResetPower();
extern uint8_t adjustPacketRateForBaud(uint8_t rate);
extern uint8_t adjustSwitchModeForAirRate(OtaSwitchMode_e eSwitchMode, uint8_t packetSize);
extern bool RxWiFiReadyToSend;
extern bool BackpackTelemReadyToSend;
extern bool TxBackpackWiFiReadyToSend;
extern bool VRxBackpackWiFiReadyToSend;
extern unsigned long rebootTime;
// setWifiUpdateMode removed for STM32 as we don't have WiFi

void TXModuleEndpoint::supressCriticalErrors()
{
    // clear the critical error bits of the warning flags
    luaWarningFlags &= 0b00011111;
}

void TXModuleEndpoint::devicePingCalled()
{
    supressCriticalErrors();
    utoa(CRSFHandset::BadPktsCountResult, luaBadGoodString, 10);
    strcat(luaBadGoodString, "/");
    utoa(CRSFHandset::GoodPktsCountResult, luaBadGoodString + strlen(luaBadGoodString), 10);
}

void TXModuleEndpoint::setWarningFlag(const warningFlags flag, const bool value)
{
  if (value)
  {
    luaWarningFlags |= 1 << (uint8_t)flag;
  }
  else
  {
    luaWarningFlags &= ~(1 << (uint8_t)flag);
  }
}

void TXModuleEndpoint::sendELRSstatus(const crsf_addr_e origin)
{
  constexpr const char *messages[] = { //higher order = higher priority
    "",                   //status2 = connected status
    "",                   //status1, reserved for future use
    "Model Mismatch",     //warning3, model mismatch
    "[ ! Armed ! ]",      //warning2, AUX1 high / armed
    "",           //warning1, reserved for future use
    "Not while connected",  //critical warning3, trying to change a protected value while connected
    "Baud rate too low",  //critical warning2, changing packet rate and baud rate too low
    ""   //critical warning1, reserved for future use
  };
  auto warningInfo = "";

  for (int i = 7; i >= 0; i--)
  {
      if (luaWarningFlags & (1 << i))
      {
          warningInfo = messages[i];
          break;
      }
  }
  const uint8_t payloadSize = sizeof(elrsStatusParameter) + strlen(warningInfo) + 1;
  uint8_t buffer[sizeof(crsf_ext_header_t) + payloadSize + 1];
  const auto params = (elrsStatusParameter *)&buffer[sizeof(crsf_ext_header_t)];

  setWarningFlag(LUA_FLAG_MODEL_MATCH, connectionState == connected && connectionHasModelMatch == false);
  setWarningFlag(LUA_FLAG_CONNECTED, connectionState == connected);
  setWarningFlag(LUA_FLAG_ISARMED, handset->IsArmed());

  params->pktsBad = CRSFHandset::BadPktsCountResult;
  params->pktsGood = htobe16(CRSFHandset::GoodPktsCountResult);
  params->flags = luaWarningFlags;
  strcpy(params->msg, warningInfo);
  crsfRouter.SetExtendedHeaderAndCrc((crsf_ext_header_t *)buffer, CRSF_FRAMETYPE_ELRS_STATUS, CRSF_EXT_FRAME_SIZE(payloadSize), origin, CRSF_ADDRESS_CRSF_TRANSMITTER);
  crsfRouter.processMessage(nullptr, (crsf_header_t *)buffer);
}

void TXModuleEndpoint::updateModelID() {
  itoa(modelId, modelMatchUnit+6, 10);
  strcat(modelMatchUnit, ")");
}

void TXModuleEndpoint::updateTlmBandwidth()
{
  const auto eRatio = (expresslrs_tlm_ratio_e)config.GetTlm();
  if (eRatio == TLM_RATIO_STD || eRatio == TLM_RATIO_DISARMED)
  {
    strcpy(tlmBandwidth, " (1:");
    const uint8_t ratioDiv = TLMratioEnumToValue(ExpressLRS_currAirRate_Modparams->TLMinterval);
    itoa(ratioDiv, &tlmBandwidth[4], 10);
    strcat(tlmBandwidth, ")");
  }
  else if (eRatio == TLM_RATIO_NO_TLM)
  {
    tlmBandwidth[0] = '\0';
  }
  else
  {
    tlmBandwidth[0] = ' ';
    const uint16_t hz = 1000000 / ExpressLRS_currAirRate_Modparams->interval;
    const uint8_t ratiodiv = TLMratioEnumToValue(eRatio);
    const uint8_t burst = TLMBurstMaxForRateRatio(hz, ratiodiv);
    const uint8_t bytesPerCall = OtaIsFullRes ? ELRS8_DATA_DL_BYTES_PER_CALL : ELRS4_DATA_DL_BYTES_PER_CALL;
    uint32_t bandwidthValue = bytesPerCall * 8U * burst * hz / ratiodiv / (burst + 1);
    if (OtaIsFullRes)
    {
      bandwidthValue += 8U * (ELRS8_DATA_DL_BYTES_PER_CALL - sizeof(OTA_LinkStats_s));
    }
    utoa(bandwidthValue, &tlmBandwidth[2], 10);
    strcat(tlmBandwidth, "bps)");
  }
}

void TXModuleEndpoint::updateBackpackOpts()
{
  if (config.GetBackpackDisable())
  {
    LUA_FIELD_HIDE(luaDvrAux);
    LUA_FIELD_HIDE(luaDvrStartDelay);
    LUA_FIELD_HIDE(luaDvrStopDelay);
    LUA_FIELD_HIDE(luaHeadTrackingEnableChannel);
    LUA_FIELD_HIDE(luaHeadTrackingStartChannel);
    LUA_FIELD_HIDE(luaBackpackTelemetry);
    LUA_FIELD_HIDE(luaBackpackVersion);
  }
  else
  {
    LUA_FIELD_SHOW(luaDvrAux);
    LUA_FIELD_SHOW(luaDvrStartDelay);
    LUA_FIELD_SHOW(luaDvrStopDelay);
    LUA_FIELD_SHOW(luaHeadTrackingEnableChannel);
    LUA_FIELD_SHOW(luaHeadTrackingStartChannel);
    LUA_FIELD_SHOW(luaBackpackTelemetry);
    LUA_FIELD_SHOW(luaBackpackVersion);
  }
}

void TXModuleEndpoint::handleWifiBle(propertiesCommon *item, uint8_t arg)
{
  // Stub for STM32 (No WiFi/BLE)
  // Just respond idle to prevent hanging LUA
  sendCommandResponse((commandParameter *)item, lcsIdle, STR_EMPTYSPACE);
}

void TXModuleEndpoint::handleSimpleSendCmd(propertiesCommon *item, uint8_t arg)
{
  const char *msg = "Sending...";
  static uint32_t lastLcsPoll;
  if (arg < lcsCancel)
  {
    lastLcsPoll = millis();
    if ((void *)item == (void *)&luaBind)
    {
      msg = "Binding...";
      EnterBindingModeSafely();
    }
    else if ((void *)item == (void *)&luaVtxSend)
    {
      VtxTriggerSend();
    }
    sendCommandResponse((commandParameter *)item, lcsExecuting, msg);
  }
  else if(arg == lcsCancel || ((millis() - lastLcsPoll)> 2000))
  {
    sendCommandResponse((commandParameter *)item, lcsIdle, STR_EMPTYSPACE);
  }
}

static void updateFolderName_TxPower()
{
  const uint8_t txPwrDyn = config.GetDynamicPower() ? config.GetBoostChannel() + 1 : 0;
  uint8_t pwrFolderLabelOffset = 10; // start writing after "TX Power ("

  // Power Level
  pwrFolderLabelOffset += findSelectionLabel(&luaPower, &pwrFolderDynamicName[pwrFolderLabelOffset], config.GetPower() - MinPower);

  // Dynamic Power
  if (txPwrDyn)
  {
    pwrFolderDynamicName[pwrFolderLabelOffset++] = folderNameSeparator[0];
    pwrFolderLabelOffset += findSelectionLabel(&luaDynamicPower, &pwrFolderDynamicName[pwrFolderLabelOffset], txPwrDyn);
  }

  pwrFolderDynamicName[pwrFolderLabelOffset++] = ')';
  pwrFolderDynamicName[pwrFolderLabelOffset] = '\0';
}

static void updateFolderName_VtxAdmin()
{
  const uint8_t vtxBand = config.GetVtxBand();
  if (vtxBand)
  {
    luaVtxFolder.dyn_name = vtxFolderDynamicName;
    uint8_t vtxFolderLabelOffset = 11; // start writing after "VTX Admin ("

    // Band
    vtxFolderLabelOffset += findSelectionLabel(&luaVtxBand, &vtxFolderDynamicName[vtxFolderLabelOffset], vtxBand);
    vtxFolderDynamicName[vtxFolderLabelOffset++] = folderNameSeparator[1];

    // Channel
    vtxFolderDynamicName[vtxFolderLabelOffset++] = '1' + config.GetVtxChannel();

    // VTX Power
    const uint8_t vtxPwr = config.GetVtxPower();
    if (vtxPwr)
    {
      vtxFolderDynamicName[vtxFolderLabelOffset++] = folderNameSeparator[1];
      vtxFolderLabelOffset += findSelectionLabel(&luaVtxPwr, &vtxFolderDynamicName[vtxFolderLabelOffset], vtxPwr);

      // Pit Mode
      const uint8_t vtxPit = config.GetVtxPitmode();
      if (vtxPit != 0)
      {
        if (vtxPit != 1)
        {
          vtxFolderDynamicName[vtxFolderLabelOffset++] = folderNameSeparator[1];
          vtxFolderLabelOffset += findSelectionLabel(&luaVtxPit, &vtxFolderDynamicName[vtxFolderLabelOffset], vtxPit);
        }
        else
        {
          vtxFolderDynamicName[vtxFolderLabelOffset++] = folderNameSeparator[1];
          vtxFolderDynamicName[vtxFolderLabelOffset++] = 'P';
        }
      }
    }
    vtxFolderDynamicName[vtxFolderLabelOffset++] = ')';
    vtxFolderDynamicName[vtxFolderLabelOffset] = '\0';
  }
  else
  {
    luaVtxFolder.dyn_name = NULL;
  }
}

void TXModuleEndpoint::SetPacketRateIdx(uint8_t idx, bool forceChange)
{
  if (idx >= RATE_MAX)
    return;

  uint8_t actualRate = adjustPacketRateForBaud(idx);
  if (actualRate == ExpressLRS_currAirRate_Modparams->index)
    return;

  const auto newModParams = get_elrs_airRateConfig(actualRate);
  uint8_t newSwitchMode = adjustSwitchModeForAirRate((OtaSwitchMode_e)config.GetSwitchMode(), newModParams->PayloadLength);
  uint8_t newAntennaMode = config.GetAntennaMode();
  
  bool isDisconnected = connectionState == disconnected;
  bool isMavlinkMode = config.GetLinkMode() == TX_MAVLINK_MODE;
  if (forceChange || (newSwitchMode == OtaSwitchModeCurrent) || (isDisconnected && !isMavlinkMode))
  {
    deferExecutionMillis(10, [actualRate, newSwitchMode, newAntennaMode]() {
      config.SetRate(actualRate);
      config.SetSwitchMode(newSwitchMode);
      config.SetAntennaMode(newAntennaMode);
      SetSyncSpam();
    });
    setWarningFlag(LUA_FLAG_ERROR_BAUDRATE, actualRate != idx);
  } else {
    setWarningFlag(LUA_FLAG_ERROR_CONNECTED, true);
  }
}

void TXModuleEndpoint::SetSwitchMode(uint8_t idx)
{
  bool isDisconnected = connectionState == disconnected;
  bool isMavlinkMode = config.GetLinkMode() == TX_MAVLINK_MODE;
  if (isDisconnected && !isMavlinkMode)
  {
    config.SetSwitchMode(idx);
    OtaUpdateSerializers((OtaSwitchMode_e)idx, ExpressLRS_currAirRate_Modparams->PayloadLength);
  }
  else if (!isMavlinkMode)
  {
    setWarningFlag(LUA_FLAG_ERROR_CONNECTED, true);
  }
}

void TXModuleEndpoint::SetAntennaMode(uint8_t idx)
{
  // For STM32 DIY with Lambda80 (Single Antenna), this mostly does nothing, but safe to keep
  config.SetAntennaMode(idx);
}

void TXModuleEndpoint::SetTlmRatio(uint8_t idx)
{
  const auto eRatio = (expresslrs_tlm_ratio_e)idx;
  if (eRatio <= TLM_RATIO_DISARMED)
  {
    const bool isMavlinkMode = config.GetLinkMode() == TX_MAVLINK_MODE;
    if (!firmwareOptions.is_airport && !isMavlinkMode)
    {
      config.SetTlm(eRatio);
      SetSyncSpam();
    }
  }
}

void TXModuleEndpoint::SetPowerMax(uint8_t idx)
{
  config.SetPower(idx);
  if (!config.IsModified())
  {
      ResetPower();
  }
}

void TXModuleEndpoint::SetDynamicPower(uint8_t idx)
{
  config.SetDynamicPower(idx > 0);
  config.SetBoostChannel(idx > 0 ? idx - 1 : 0);
}

void TXModuleEndpoint::updateFolderNames()
{
  updateFolderName_TxPower();
  updateFolderName_VtxAdmin();
  updateTlmBandwidth();
  updateBackpackOpts();
}

static void recalculatePacketRateOptions(int minInterval)
{
    const char *allRates = STR_LUA_PACKETRATES;
    const char *pos = allRates;
    luastrPacketRates[0] = 0;
    for (int i=0 ; i < RATE_MAX ; i++)
    {
        uint8_t rate = i;
        rate = RATE_MAX - 1 - rate;
        bool rateAllowed = (get_elrs_airRateConfig(rate)->interval * get_elrs_airRateConfig(rate)->numOfSends) >= minInterval;
        
        // Lambda80 is SX1280 (LoRa) or FLRC. Check generic support
        rateAllowed &= isSupportedRFRate(rate);

        const char *semi = strchrnul_local(pos, ';');
        if (rateAllowed)
        {
            strncat(luastrPacketRates, pos, semi - pos);
        }
        pos = semi;
        if (*semi == ';')
        {
            strcat(luastrPacketRates, ";");
            pos = semi+1;
        }
    }

    size_t lastPos = strlen(luastrPacketRates);
    while (lastPos > 0 && luastrPacketRates[lastPos - 1] == ';')
    {
        luastrPacketRates[lastPos - 1] = '\0';
        --lastPos;
    }
}

void TXModuleEndpoint::registerParameters()
{
  setStringValue(&luaInfo, luaBadGoodString);

  auto wifiBleCallback = [&](propertiesCommon *item, const uint8_t arg) { handleWifiBle(item, arg); };
  auto sendCallback = [&](propertiesCommon *item, const uint8_t arg) { handleSimpleSendCmd(item, arg); };

  if (HAS_RADIO) {
    registerParameter(&luaAirRate, [this](propertiesCommon *item, uint8_t arg) {
      uint8_t selectedRate = RATE_MAX - 1 - arg;
      SetPacketRateIdx(selectedRate, true);
    });
    registerParameter(&luaTlmRate, [this](propertiesCommon *item, uint8_t arg) {
      SetTlmRatio(arg);
    });
    if (!firmwareOptions.is_airport)
    {
      registerParameter(&luaSwitch, [this](propertiesCommon *item, uint8_t arg) {
        SetSwitchMode(arg);
      });
    }
    
    if (isDualRadio()) // Likely false for Lambda80
    {
      registerParameter(&luaAntenna, [this](propertiesCommon *item, uint8_t arg) {
        SetAntennaMode(arg);
      });
    }

    registerParameter(&luaLinkMode, [this](propertiesCommon *item, uint8_t arg) {
      bool isDisconnected = connectionState == disconnected;
      if (isDisconnected)
      {
        config.SetLinkMode(arg);
      }
      else
      {
        setWarningFlag(LUA_FLAG_ERROR_CONNECTED, true);
      }
    });
    
    if (!firmwareOptions.is_airport)
    {
      registerParameter(&luaModelMatch, [this](propertiesCommon *item, uint8_t arg) {
        bool newModelMatch = arg;
        config.SetModelMatch(newModelMatch);
        if (connectionState == connected)
        {
          mspPacket_t msp;
          msp.reset();
          msp.makeCommand();
          msp.function = MSP_SET_RX_CONFIG;
          msp.addByte(MSP_ELRS_MODEL_ID);
          msp.addByte(newModelMatch ? modelId : 0xff);
          crsfRouter.AddMspMessage(&msp, CRSF_ADDRESS_CRSF_RECEIVER, CRSF_ADDRESS_CRSF_TRANSMITTER);
        }
        updateModelID();
      });
    }

    // POWER folder
    registerParameter(&luaPowerFolder);
    filterOptions(&luaPower, POWERMGNT::getMinPower(), POWERMGNT::getMaxPower(), strPowerLevels);
    registerParameter(&luaPower, [this](propertiesCommon *item, uint8_t arg) {
      SetPowerMax(constrain(arg + POWERMGNT::getMinPower(), POWERMGNT::getMinPower(), POWERMGNT::getMaxPower()));
    }, luaPowerFolder.common.id);
    registerParameter(&luaDynamicPower, [this](propertiesCommon *item, uint8_t arg) {
      SetDynamicPower(arg);
    }, luaPowerFolder.common.id);
  }
  
  if (GPIO_PIN_FAN_EN != UNDEF_PIN || GPIO_PIN_FAN_PWM != UNDEF_PIN) {
    registerParameter(&luaFanThreshold, [](propertiesCommon *item, uint8_t arg){
      config.SetPowerFanThreshold(arg);
    }, luaPowerFolder.common.id);
  }

  if ((HAS_RADIO || (bool)OPT_USE_TX_BACKPACK) && !firmwareOptions.is_airport) {
    // VTX folder
    registerParameter(&luaVtxFolder);
    registerParameter(&luaVtxBand, [](propertiesCommon *item, uint8_t arg) {
      config.SetVtxBand(arg);
    }, luaVtxFolder.common.id);
    registerParameter(&luaVtxChannel, [](propertiesCommon *item, uint8_t arg) {
      config.SetVtxChannel(arg - 1);
    }, luaVtxFolder.common.id);
    registerParameter(&luaVtxPwr, [](propertiesCommon *item, uint8_t arg) {
      config.SetVtxPower(arg);
    }, luaVtxFolder.common.id);
    registerParameter(&luaVtxPit, [](propertiesCommon *item, uint8_t arg) {
      config.SetVtxPitmode(arg);
    }, luaVtxFolder.common.id);
    registerParameter(&luaVtxSend, sendCallback, luaVtxFolder.common.id);
  }

  // WIFI folder (Hidden or Stubbed for STM32)
  // We can leave them here but since handleWifiBle does nothing, clicking them won't crash
  registerParameter(&luaWiFiFolder);
  registerParameter(&luaWebUpdate, wifiBleCallback, luaWiFiFolder.common.id);
  
  if (HAS_RADIO) {
    registerParameter(&luaRxWebUpdate, sendCallback, luaWiFiFolder.common.id);

    if ((bool)OPT_USE_TX_BACKPACK) {
      registerParameter(&luaTxBackpackUpdate, sendCallback, luaWiFiFolder.common.id);
      registerParameter(&luaVRxBackpackUpdate, sendCallback, luaWiFiFolder.common.id);
      
      // Backpack folder
      registerParameter(&luaBackpackFolder);
      // ... [Backpack params skipped if disabled] ...
    }
  }

  if (HAS_RADIO) {
    registerParameter(&luaBind, sendCallback);
  }

  registerParameter(&luaInfo);
  if (strlen(version) < 21) {
    strlcpy(version_domain, version, 21);
    strlcat(version_domain, " ", sizeof(version_domain));
  } else {
    strlcpy(version_domain, version, 18);
    strlcat(version_domain, "... ", sizeof(version_domain));
  }
  strlcat(version_domain, FHSSconfig->domain, sizeof(version_domain));
  registerParameter(&luaELRSversion);
}

void TXModuleEndpoint::updateParameters()
{
  bool isMavlinkMode = config.GetLinkMode() == TX_MAVLINK_MODE;
  uint8_t currentRate = adjustPacketRateForBaud(config.GetRate());

  recalculatePacketRateOptions(handset->getMinPacketInterval());
  setTextSelectionValue(&luaAirRate, RATE_MAX - 1 - currentRate);

  setTextSelectionValue(&luaTlmRate, config.GetTlm());
  luaTlmRate.options = isMavlinkMode ? tlmRatiosMav : tlmRatios;

  luaAntenna.options = antennamodeOpts;

  setTextSelectionValue(&luaSwitch, config.GetSwitchMode());
  if (isMavlinkMode)
  {
    luaSwitch.options = OtaIsFullRes ? switchmodeOpts8chMav : switchmodeOpts4chMav;
  }
  else
  {
    luaSwitch.options = OtaIsFullRes ? switchmodeOpts8ch : switchmodeOpts4ch;
  }

  if (isDualRadio())
  {
    setTextSelectionValue(&luaAntenna, config.GetAntennaMode());
  }
  setTextSelectionValue(&luaLinkMode, config.GetLinkMode());
  updateModelID();
  setTextSelectionValue(&luaModelMatch, (uint8_t)config.GetModelMatch());
  setTextSelectionValue(&luaPower, config.GetPower() - MinPower);
  if (GPIO_PIN_FAN_EN != UNDEF_PIN || GPIO_PIN_FAN_PWM != UNDEF_PIN)
  {
    setTextSelectionValue(&luaFanThreshold, config.GetPowerFanThreshold());
  }

  uint8_t dynamic = config.GetDynamicPower() ? config.GetBoostChannel() + 1 : 0;
  setTextSelectionValue(&luaDynamicPower, dynamic);

  setTextSelectionValue(&luaVtxBand, config.GetVtxBand());
  setUint8Value(&luaVtxChannel, config.GetVtxChannel() + 1);
  setTextSelectionValue(&luaVtxPwr, config.GetVtxPower());
  LUA_FIELD_VISIBLE(luaVtxPit, config.GetVtxPower() != 0);
  setTextSelectionValue(&luaVtxPit, config.GetVtxPitmode());
  
  if ((bool)OPT_USE_TX_BACKPACK)
  {
    // These will be hidden/unused if OPT_USE_TX_BACKPACK is 0
    setTextSelectionValue(&luaBackpackEnable, config.GetBackpackDisable() ? 0 : 1);
    // ... [Other Backpack setters]
  }
  updateFolderNames();
}
