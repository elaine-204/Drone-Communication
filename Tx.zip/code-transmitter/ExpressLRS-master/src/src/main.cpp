// ============================================================
//  main_postinvert.cpp
//
//  Use this AFTER wiring the hardware inverter on PA10.
//  Tries 420000 and 416666 baud, prints raw hex of first
//  64 bytes at each so you can visually confirm C8 18 16.
//  Once confirmed, the winning baud is locked in.
// ============================================================

#include <Arduino.h>
#include <HardwareSerial.h>
#include "stm32f4xx_hal.h"
#include "crsf_protocol.h"
#include "SX.h"
#include "boxes.h"

HardwareSerial DebugSerial(PA3, PA2);
SPI_HandleTypeDef  hspi1;
UART_HandleTypeDef huart1;

// ── Channel data ─────────────────────────────────────────────
uint32_t ChannelData[16] = {
    1500,1500,1500,1500,1500,1500,1500,1500,
    1500,1500,1500,1500,1500,1500,1500,1500
};
uint32_t txOK=0, txFail=0, rawBytes=0;
bool gotFrame = false;

// ============================================================
//  Frequency Hopping Setup
// ============================================================

// Frequencies in Hz (within 2.4 GHz band)
uint32_t hopFrequencies[] = {
    2402000000UL,  // Channel 1
    2405000000UL,  // Channel 2
    2408000000UL,  // Channel 3
    2412000000UL   // Channel 4
};

// Custom hopping sequence (INDEXES of above array)
uint8_t hopSequence[] = {
    0,  // Ch1
    2,  // Ch3
    0,  // Ch1
    3,  // Ch4
    1,  // Ch2
    2,  // Ch3
    3,  // Ch4
    0,  // Ch1
    1,  // Ch2
    2   // Ch3
};

#define HOP_SEQUENCE_LENGTH (sizeof(hopSequence)/sizeof(hopSequence[0]))

uint8_t hopStep = 0;

// How fast we hop (ms)
#define HOP_INTERVAL 50   // change freq every 50 ms

uint32_t lastHopTime = 0;

// ============================================================
//  Hardware init
// ============================================================
static void MX_GPIO_Init(void) {
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    GPIO_InitTypeDef g = {0};

    // PA4 NSS
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
    g.Pin=GPIO_PIN_4; g.Mode=GPIO_MODE_OUTPUT_PP; g.Pull=GPIO_NOPULL; g.Speed=GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &g);

    // PA8 BUSY
    g.Pin=GPIO_PIN_8; g.Mode=GPIO_MODE_INPUT; g.Pull=GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &g);

    // PB0 DIO1
    g.Pin=GPIO_PIN_0; g.Mode=GPIO_MODE_INPUT; g.Pull=GPIO_NOPULL;
    HAL_GPIO_Init(GPIOB, &g);

    // PB1 RESET
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET);
    g.Pin=GPIO_PIN_1; g.Mode=GPIO_MODE_OUTPUT_PP; g.Pull=GPIO_NOPULL; g.Speed=GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &g);
}

static void MX_SPI1_Init(void) {
    __HAL_RCC_SPI1_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    GPIO_InitTypeDef g = {0};
    g.Pin=GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7; g.Mode=GPIO_MODE_AF_PP;
    g.Pull=GPIO_NOPULL; g.Speed=GPIO_SPEED_FREQ_VERY_HIGH; g.Alternate=GPIO_AF5_SPI1;
    HAL_GPIO_Init(GPIOA, &g);

    hspi1.Instance               = SPI1;
    hspi1.Init.Mode              = SPI_MODE_MASTER;
    hspi1.Init.Direction         = SPI_DIRECTION_2LINES;
    hspi1.Init.DataSize          = SPI_DATASIZE_8BIT;
    hspi1.Init.CLKPolarity       = SPI_POLARITY_LOW;
    hspi1.Init.CLKPhase          = SPI_PHASE_1EDGE;
    hspi1.Init.NSS               = SPI_NSS_SOFT;
    hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_64;
    hspi1.Init.FirstBit          = SPI_FIRSTBIT_MSB;
    hspi1.Init.TIMode            = SPI_TIMODE_DISABLE;
    hspi1.Init.CRCCalculation    = SPI_CRCCALCULATION_DISABLE;
    HAL_SPI_Init(&hspi1);
}

static void MX_UART_Init(uint32_t baud) {
    HAL_UART_DeInit(&huart1);
    __HAL_RCC_USART1_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    GPIO_InitTypeDef g = {0};
    g.Pin=GPIO_PIN_9|GPIO_PIN_10; g.Mode=GPIO_MODE_AF_PP;
    // After hardware inverter, signal idles HIGH again — use pull-up
    g.Pull=GPIO_PULLUP; g.Speed=GPIO_SPEED_FREQ_VERY_HIGH; g.Alternate=GPIO_AF7_USART1;
    HAL_GPIO_Init(GPIOA, &g);

    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = baud;
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;
    huart1.Init.StopBits     = UART_STOPBITS_1;
    huart1.Init.Parity       = UART_PARITY_NONE;
    huart1.Init.Mode         = UART_MODE_RX;
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    HAL_UART_Init(&huart1);
    // NO RXINV — hardware inverter does this for us now
}

// ============================================================
//  Quick baud confirmation: capture 78 bytes and check for
//  C8 18 16 pattern (3 complete CRSF RC frames)
// ============================================================
static bool confirm_baud(uint32_t baud) {
    MX_UART_Init(baud);
    HAL_Delay(100);

    uint8_t buf[78];
    uint8_t pos = 0;
    uint32_t start = HAL_GetTick();

    while (pos < 78 && HAL_GetTick() - start < 500) 
    {
        if (huart1.Instance->SR & (USART_SR_ORE|USART_SR_FE|USART_SR_NE)) {
            (void)huart1.Instance->SR;
            (void)huart1.Instance->DR;
            continue;
        }
        if (huart1.Instance->SR & USART_SR_RXNE) {
            buf[pos++] = (uint8_t)(huart1.Instance->DR & 0xFF);
        }
    }

    DebugSerial.printf("\r\n--- %lu baud raw hex ---\r\n", baud);
    for (int i = 0; i < pos; i++) {
        if (i % 16 == 0) DebugSerial.printf("%04X  ", i);
        DebugSerial.printf("%02X ", buf[i]);
        if (i % 16 == 7)  DebugSerial.print(" ");
        if (i % 16 == 15) DebugSerial.print("\r\n");
    }
    DebugSerial.print("\r\n");

    // Look for C8 18 16 — the definitive CRSF RC frame header
    int hits = 0;
    for (int i = 0; i + 2 < pos; i++) {
        if (buf[i] == 0xC8 && buf[i+1] == 0x18 && buf[i+2] == 0x16) {
            hits++;
            DebugSerial.printf("  >> CRSF header found at offset %d!\r\n", i);
        }
    }
    // Also accept 0xEE header (TX module address)
    for (int i = 0; i + 2 < pos; i++) {
        if (buf[i] == 0xEE && buf[i+1] == 0x18 && buf[i+2] == 0x16) {
            hits++;
            DebugSerial.printf("  >> CRSF header (0xEE) found at offset %d!\r\n", i);
        }
    }

    if (hits > 0) {
        DebugSerial.printf("  CONFIRMED: %lu baud is correct! (%d headers found)\r\n", baud, hits);
        return true;
    }
    DebugSerial.printf("  No CRSF headers found at %lu baud.\r\n", baud);
    return false;
}

// ============================================================
//  CRSF parser (same as main.cpp)
// ============================================================
#define CRSF_BUF_SIZE 64
static uint8_t  crsf_buf[CRSF_BUF_SIZE];
static uint8_t  crsf_pos = 0;
static uint8_t  crsf_len = 0;
static uint32_t lastByteTime = 0;

static inline void uart_drain_errors(void) {
    if (huart1.Instance->SR & (USART_SR_ORE|USART_SR_FE|USART_SR_NE)) {
        (void)huart1.Instance->SR;
        (void)huart1.Instance->DR;
    }
}

static void crsf_handle_byte(uint8_t b) {
    rawBytes++;
    uint32_t now = millis();
    if (now - lastByteTime > 3) crsf_pos = 0;
    lastByteTime = now;

    if (crsf_pos == 0) {
        if (b == 0xC8 || b == 0xEA || b == 0xEE) {
            crsf_buf[crsf_pos++] = b;
        }
        return;
    }
    if (crsf_pos == 1) {
        if (b < 2 || b > 62) { crsf_pos = 0; return; }
        crsf_len = b;
        crsf_buf[crsf_pos++] = b;
        return;
    }
    crsf_buf[crsf_pos++] = b;

    if (crsf_pos == (uint8_t)(crsf_len + 2)) {
        if (crsf_buf[2] == CRSF_FRAMETYPE_RC_CHANNELS_PACKED) {
            uint8_t payload_len = crsf_len - 2;
            uint8_t rx_crc  = crsf_buf[crsf_pos - 1];
            uint8_t calc_crc = crsf_crc8(&crsf_buf[2], payload_len + 1);
            if (rx_crc == calc_crc) {
                uint32_t raw[16];
                crsf_unpack_channels(&crsf_buf[3], raw);
                for (int i = 0; i < 16; i++) ChannelData[i] = crsf_to_us(raw[i]);
                gotFrame = true;
            }
        }
        crsf_pos = 0;
        return;
    }
    if (crsf_pos >= CRSF_BUF_SIZE) crsf_pos = 0;
}

static void crsf_poll(void) {
    uart_drain_errors();
    while (huart1.Instance->SR & USART_SR_RXNE) {
        crsf_handle_byte((uint8_t)(huart1.Instance->DR & 0xFF));
    }
}

// AES-128 

void KeyExpansionCore(unsigned char* in, unsigned char i)
{
	//Rotate Left
	unsigned int* q = (unsigned int*)in;
	*q = (*q >> 8) | ((*q & 0xff) << 24);

	//S-BOX 4Bytes
	in[0] = s_box[in[0]];
	in[1] = s_box[in[1]];
	in[2] = s_box[in[2]];
	in[3] = s_box[in[3]];

	//RCon
	in[0] ^= rcon[i];
}
void KeyExpansion(unsigned char* inputKey, unsigned char* expandedKeys)
{
	for (int i = 0; i < 16; i++)
		expandedKeys[i] = inputKey[i];

	int bytesGenerated = 16;
	int rconIteration = 1;
	unsigned char temp[4];

	while (bytesGenerated < 176)
	{
		for (int i = 0; i < 4; i++)
			temp[i] = expandedKeys[i + bytesGenerated - 4];

		if (bytesGenerated % 16 == 0)
		{
			KeyExpansionCore(temp, rconIteration);
			rconIteration++;
		}

		for (unsigned char a = 0; a < 4; a++)
		{
			expandedKeys[bytesGenerated]= expandedKeys[bytesGenerated - 16] ^ temp[a];
			bytesGenerated++;
		}
	}
}
void SubBytes(unsigned char* state)
{
	for (int i = 0; i < 16; i++)
		state[i] = s_box[state[i]];
}
void ShiftRows(unsigned char* state)
{
	unsigned char tmp[16];

	tmp[0] = state[0];
	tmp[1] = state[5];
	tmp[2] = state[10];
	tmp[3] = state[15];

	tmp[4] = state[4];
	tmp[5] = state[9];
	tmp[6] = state[14];
	tmp[7] = state[3];

	tmp[8] = state[8];
	tmp[9] = state[13];
	tmp[10] = state[2];
	tmp[11] = state[7];

	tmp[12] = state[12];
	tmp[13] = state[1];
	tmp[14] = state[6];
	tmp[15] = state[11];

	for (int i = 0; i < 16; i++)
		state[i] = tmp[i];
}
void MixColumns(unsigned char* state)
{
	unsigned char tmp[16];

	tmp[0] = (unsigned char)(mul2[state[0]] ^ mul3[state[1]] ^ state[2] ^ state[3]);
	tmp[1] = (unsigned char)(state[0] ^ mul2[state[1]] ^ mul3[state[2]] ^ state[3]);
	tmp[2] = (unsigned char)(state[0] ^ state[1] ^ mul2[state[2]] ^ mul3[state[3]]);
	tmp[3] = (unsigned char)(mul3[state[0]] ^ state[1] ^ state[2] ^ mul2[state[3]]);

	tmp[4] = (unsigned char)(mul2[state[4]] ^ mul3[state[5]] ^ state[6] ^ state[7]);
	tmp[5] = (unsigned char)(state[4] ^ mul2[state[5]] ^ mul3[state[6]] ^ state[7]);
	tmp[6] = (unsigned char)(state[4] ^ state[5] ^ mul2[state[6]] ^ mul3[state[7]]);
	tmp[7] = (unsigned char)(mul3[state[4]] ^ state[5] ^ state[6] ^ mul2[state[7]]);

	tmp[8] = (unsigned char)(mul2[state[8]] ^ mul3[state[9]] ^ state[10] ^ state[11]);
	tmp[9] = (unsigned char)(state[8] ^ mul2[state[9]] ^ mul3[state[10]] ^ state[11]);
	tmp[10] = (unsigned char)(state[8] ^ state[9] ^ mul2[state[10]] ^ mul3[state[11]]);
	tmp[11] = (unsigned char)(mul3[state[8]] ^ state[9] ^ state[10] ^ mul2[state[11]]);

	tmp[12] = (unsigned char)(mul2[state[12]] ^ mul3[state[13]] ^ state[14] ^ state[15]);
	tmp[13] = (unsigned char)(state[12] ^ mul2[state[13]] ^ mul3[state[14]] ^ state[15]);
	tmp[14] = (unsigned char)(state[12] ^ state[13] ^ mul2[state[14]] ^ mul3[state[15]]);
	tmp[15] = (unsigned char)(mul3[state[12]] ^ state[13] ^ state[14] ^ mul2[state[15]]);

	for (int i = 0; i<16; i++)
		state[i] = tmp[i];

}
void AddRoundKey(unsigned char* state, unsigned char* roundKey)
{
	for (int i = 0; i < 16; i++)
		state[i] ^= roundKey[i];
}
void AES_Encrypt(unsigned char* message, unsigned char* key)
{
	unsigned char state[16];
	for (int i = 0; i < 16; i++)
		state[i] = message[i];

	int numberOfRounds = 9;
	unsigned char expandedKey[176];
	//Initial Round
	KeyExpansion(key,expandedKey);
	AddRoundKey(state,key);

	//Common Rounds
	for (int i = 0; i < numberOfRounds; i++)
	{
		SubBytes(state);
		ShiftRows(state);
		MixColumns(state);
		AddRoundKey(state,expandedKey+(16*(i+1)));
	}
	//Final Round
	SubBytes(state);
	ShiftRows(state);
	AddRoundKey(state,expandedKey+160);

	for (int i = 0; i < 16; i++)
	{
		message[i] = state[i];
	}
}

unsigned char AES_Key[16] = {
0x50,0x41,0x53,0x53,
0x57,0x4F,0x52,0x44,
0x31,0x32,0x33,0x34,
0x35,0x36,0x37,0x38
};
// P A S S W O R D 1 2 3 4 5 6 7 8

// ============================================================
//  setup
// ============================================================
void setup() {
    DebugSerial.begin(115200);
    HAL_Delay(1000);
    DebugSerial.print("\r\n=== POST-INVERTER CRSF TEST ===\r\n");
    DebugSerial.print("Hardware inverter should be wired on PA10.\r\n\r\n");

    MX_GPIO_Init();
    MX_SPI1_Init();

    // ── Try to confirm baud rate ──────────────────────────────
    uint32_t good_baud = 0;

    if (confirm_baud(420000)) {
        good_baud = 420000;
    } else if (confirm_baud(416666)) {
        good_baud = 416666;
    } else if (confirm_baud(400000)) {
        good_baud = 400000;
    } else {
        DebugSerial.print("\r\nERROR: No valid CRSF signal found after inverter.\r\n");
        DebugSerial.print("Check:\r\n");
        DebugSerial.print("  - Transistor collector connected to PA10\r\n");
        DebugSerial.print("  - 10k pull-up connected to 3.3V (NOT 5V)\r\n");
        DebugSerial.print("  - JR bay signal connected to transistor base via 4.7k\r\n");
        DebugSerial.print("  - Emitter to GND\r\n");
        DebugSerial.print("Halting.\r\n");
        while(1) {}
    }

    DebugSerial.printf("\r\nUsing %lu baud. Initialising radio...\r\n", good_baud);

    // Lock in the confirmed baud for normal operation
    MX_UART_Init(good_baud);

    SX1280_Init(hopFrequencies[0], 13);
    SX1280_SetSyncWord(0x1424);
    DebugSerial.print("SX1280 ready.\r\n");
    DebugSerial.print("Waiting for CRSF frames...\r\n\r\n");
}

// ============================================================
//  loop
// ============================================================
static uint32_t lastTxTime    = 0;
static uint32_t lastPrintTime = 0;

void loop() {
    crsf_poll();
    uint32_t now = millis();

    if (now - lastTxTime >= 10) {
        lastTxTime = now;
// ============================================================
//  Custom Sequence Frequency Hopping
// ============================================================
 if (now - lastHopTime >= HOP_INTERVAL) {
            lastHopTime = now;

            uint8_t channelIndex = hopSequence[hopStep];

            SX1280_SetRfFrequency(hopFrequencies[channelIndex]);

            DebugSerial.printf("Hop step %d → Channel %d → %lu Hz\r\n",
                hopStep,
                channelIndex + 1,
                hopFrequencies[channelIndex]
            );

            hopStep = (hopStep + 1) % HOP_SEQUENCE_LENGTH;
        }

        uint8_t payload[32];
        for (int i = 0; i < 16; i++) {
            payload[i*2]   = (uint8_t)(ChannelData[i] >> 8);
            payload[i*2+1] = (uint8_t)(ChannelData[i] & 0xFF);
        }
        // encrypt
        AES_Encrypt(&payload[0], AES_Key);
        AES_Encrypt(&payload[16], AES_Key);
        SX1280_ClearIrq(SX_IRQ_ALL);
        SX1280_WriteBuf(0x00, payload, 32);
        uint8_t tx_start[3] = {0x02, 0x00, 0x00};
        SX1280_WriteCmd(SX_CMD_SET_TX, tx_start, 3);

        uint32_t ws = millis();
        bool done = false;
        while (millis() - ws < 15) {
            crsf_poll();
            if (SX1280_GetIrq() & SX_IRQ_TX_DONE) { done = true; break; }
        }
        SX1280_ClearIrq(SX_IRQ_ALL);
        if (done) txOK++; else txFail++;
    }

    if (now - lastPrintTime >= 500) {
        lastPrintTime = now;
        if (!gotFrame) {
            DebugSerial.printf("No frame yet. rawBytes=%lu\r\n", rawBytes);
        } else {
            DebugSerial.printf(
                "CH1:%4lu CH2:%4lu CH3:%4lu CH4:%4lu | TX_OK:%lu FAIL:%lu\r\n",
                ChannelData[0], ChannelData[1], ChannelData[2], ChannelData[3],
                txOK, txFail
            );
        }
    }
}