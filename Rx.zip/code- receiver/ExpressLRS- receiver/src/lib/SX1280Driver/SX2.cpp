/*
 * sx1280.c
 * Exact copy of your working RX sx1280.c.
 * BUSY pin is PA8 (defined in sx1280.h).
 */

#include "SX2.h"
#include "stm32f4xx_hal.h"

extern UART_HandleTypeDef huart2;
extern SPI_HandleTypeDef  hspi1;

void SX1280_WaitBusy(void)
{
    uint32_t timeout = 100000;
    while (HAL_GPIO_ReadPin(SX_BUSY_PORT, SX_BUSY_PIN) == GPIO_PIN_SET)
    {
        if (--timeout == 0)
        {
            HAL_UART_Transmit(&huart2, (uint8_t*)"BUSY TIMEOUT\r\n", 14, 100);
            break;
        }
    }
}

void SX1280_WriteCmd(uint8_t cmd, uint8_t* data, uint8_t len)
{
    SX1280_WaitBusy();
    HAL_GPIO_WritePin(SX_NSS_PORT, SX_NSS_PIN, GPIO_PIN_RESET);
    HAL_SPI_Transmit(&hspi1, &cmd, 1, HAL_MAX_DELAY);
    if (len > 0 && data != NULL)
        HAL_SPI_Transmit(&hspi1, data, len, HAL_MAX_DELAY);
    HAL_GPIO_WritePin(SX_NSS_PORT, SX_NSS_PIN, GPIO_PIN_SET);
    SX1280_WaitBusy();
}

void SX1280_ReadCmd(uint8_t cmd, uint8_t* txData, uint8_t txLen,
                    uint8_t* rxData, uint8_t rxLen)
{
    SX1280_WaitBusy();
    HAL_GPIO_WritePin(SX_NSS_PORT, SX_NSS_PIN, GPIO_PIN_RESET);
    HAL_SPI_Transmit(&hspi1, &cmd, 1, HAL_MAX_DELAY);
    if (txLen > 0 && txData != NULL)
        HAL_SPI_Transmit(&hspi1, txData, txLen, HAL_MAX_DELAY);
    if (rxLen > 0 && rxData != NULL)
        HAL_SPI_Receive(&hspi1, rxData, rxLen, HAL_MAX_DELAY);
    HAL_GPIO_WritePin(SX_NSS_PORT, SX_NSS_PIN, GPIO_PIN_SET);
    SX1280_WaitBusy();
}

void SX1280_Init(void)
{
    HAL_GPIO_WritePin(SX_NSS_PORT, SX_NSS_PIN, GPIO_PIN_SET);
}

void SX1280_SetStandby(void)
{
    uint8_t mode = 0x01;
    SX1280_WriteCmd(CMD_SET_STANDBY, &mode, 1);
}

void SX1280_SetPacketType_LoRa(void)
{
    uint8_t mode = 0x01;
    SX1280_WriteCmd(CMD_SET_PACKET_TYPE, &mode, 1);
}

void SX1280_SetRfFrequency(uint32_t freq_hz)
{
    uint32_t steps = (uint32_t)((double)freq_hz / 198.3642578);
    uint8_t buf[3];
    buf[0] = (steps >> 16) & 0xFF;
    buf[1] = (steps >>  8) & 0xFF;
    buf[2] =  steps        & 0xFF;
    SX1280_WriteCmd(CMD_SET_RF_FREQ, buf, 3);
}

void SX1280_SetLoRaModulationParams(void)
{
    /* MUST match TX bridge exactly: SF9, BW1600, CR4/5 */
    uint8_t buf[3];
    buf[0] = 0x90; // SF : 0x50, 60, 70, 80, 90, A0, B0, C0
    buf[1] = 0x0A; // BW : 1600(0x0A), 800(0x18), 400(0x26), 200(0x34)
    buf[2] = 0x01; // CR : 4/5(0x01), 4/6(0x02), 4/7(0x03), 4/8(0x04)
    SX1280_WriteCmd(CMD_SET_MODULATION_PARAMS, buf, 3);
}

void SX1280_SetLoRaPacketParams(void)
{
    uint8_t buf[7];
    buf[0] = (uint8_t)12;    //preamble
    buf[1] = 0x00;   //header. explicit0x00, implicit0x80
    buf[2] = 32;  //payload length (uint8_t)8
    buf[3] = 0x20;   //crc. on:0x20, OFF:0x00
    buf[4] = 0x40;   // IQ. normal:0x40, inverted:0x00
    buf[5] = 0x00;
    buf[6] = 0x00;
    SX1280_WriteCmd(CMD_SET_PACKET_PARAMS, buf, 7);
}

void SX1280_SetDioIrqParams(uint16_t irqMask, uint16_t dio1Mask,
                             uint16_t dio2Mask, uint16_t dio3Mask)
{
    uint8_t buf[8];
    buf[0] = (uint8_t)(irqMask  >> 8);  buf[1] = (uint8_t)(irqMask  & 0xFF);
    buf[2] = (uint8_t)(dio1Mask >> 8);  buf[3] = (uint8_t)(dio1Mask & 0xFF);
    buf[4] = (uint8_t)(dio2Mask >> 8);  buf[5] = (uint8_t)(dio2Mask & 0xFF);
    buf[6] = (uint8_t)(dio3Mask >> 8);  buf[7] = (uint8_t)(dio3Mask & 0xFF);
    SX1280_WriteCmd(CMD_SET_DIO_IRQ_PARAMS, buf, 8);
}

void SX1280_SetBufferBaseAddress(uint8_t txBaseAddress, uint8_t rxBaseAddress)
{
    uint8_t buf[2] = {txBaseAddress, rxBaseAddress};
    SX1280_WriteCmd(SX1280_SET_BUFFERBASEADDRESS, buf, 2);
}

void SX1280_ClearIrqStatus(uint16_t irqMask)
{
    uint8_t buf[2];
    buf[0] = (uint8_t)(irqMask >> 8);
    buf[1] = (uint8_t)(irqMask & 0xFF);
    SX1280_WriteCmd(CMD_CLEAR_IRQ_STATUS, buf, 2);
}

uint16_t SX1280_GetIrqStatus(void)
{
    uint8_t rxBuf[3] = {0, 0, 0};
    SX1280_ReadCmd(CMD_GET_IRQ_STATUS, NULL, 0, rxBuf, 3);
    return ((uint16_t)rxBuf[1] << 8) | rxBuf[2];
}

void SX1280_SetRx(uint16_t timeout_ms)
{
    uint8_t buf[3];
    SX1280_ClearIrqStatus(0xFFFF);
    buf[0] = 0x02;
    if (timeout_ms == 0) {
        buf[1] = 0xFF; buf[2] = 0xFF;
    } else {
        buf[1] = (uint8_t)((timeout_ms >> 8) & 0xFF);
        buf[2] = (uint8_t)( timeout_ms       & 0xFF);
    }
    SX1280_WriteCmd(CMD_SET_RX, buf, 3);
}

void SX1280_GetPayload(uint8_t* buffer, uint8_t* size, uint8_t max_size)
{
    // GetRxBufferStatus returns: [status] [payloadLen] [bufferOffset]
    // Read 3 bytes, skip status byte at [0]
    uint8_t statusBuf[3] = {0, 0, 0};
    SX1280_ReadCmd(CMD_GET_RX_BUFFER_STATUS, NULL, 0, statusBuf, 3);

    uint8_t payLen    = statusBuf[1];  // ← was [0], now [1]
    uint8_t payOffset = statusBuf[2];  // ← was [1], now [2]

    if (payLen > max_size) payLen = max_size;
    *size = payLen;

    SX1280_WaitBusy();
    HAL_GPIO_WritePin(SX_NSS_PORT, SX_NSS_PIN, GPIO_PIN_RESET);
    uint8_t cmd = CMD_READ_BUFFER;
    uint8_t nop = 0x00;
    HAL_SPI_Transmit(&hspi1, &cmd,       1, HAL_MAX_DELAY);
    HAL_SPI_Transmit(&hspi1, &payOffset, 1, HAL_MAX_DELAY);
    HAL_SPI_Transmit(&hspi1, &nop,       1, HAL_MAX_DELAY);
    HAL_SPI_Receive (&hspi1, buffer, payLen, HAL_MAX_DELAY);
    HAL_GPIO_WritePin(SX_NSS_PORT, SX_NSS_PIN, GPIO_PIN_SET);
    SX1280_WaitBusy();
}

void SX1280_GetPacketStatus(int8_t* rssi, int8_t* snr)
{
    uint8_t buf[3] = {0, 0, 0};
    SX1280_ReadCmd(CMD_GET_PACKET_STATUS, NULL, 0, buf, 3);
    *rssi = -(buf[1] / 2);
    *snr  =  (int8_t)buf[2] / 4;
}

void SX1280_WriteRegister(uint16_t address, uint8_t value)
{
    uint8_t opcode = CMD_Write_Register;
    uint8_t addr_h = (address >> 8) & 0xFF;
    uint8_t addr_l =  address       & 0xFF;
    SX1280_WaitBusy();
    HAL_GPIO_WritePin(SX_NSS_PORT, SX_NSS_PIN, GPIO_PIN_RESET);
    HAL_SPI_Transmit(&hspi1, &opcode, 1, HAL_MAX_DELAY);
    HAL_SPI_Transmit(&hspi1, &addr_h, 1, HAL_MAX_DELAY);
    HAL_SPI_Transmit(&hspi1, &addr_l, 1, HAL_MAX_DELAY);
    HAL_SPI_Transmit(&hspi1, &value,  1, HAL_MAX_DELAY);
    HAL_GPIO_WritePin(SX_NSS_PORT, SX_NSS_PIN, GPIO_PIN_SET);
    SX1280_WaitBusy();
}

void SX1280_SetLoRaSyncWord(uint16_t syncWord)
{
    SX1280_WriteRegister(REG_LR_SYNC_WORD_MSB, (syncWord >> 8) & 0xFF);
    SX1280_WriteRegister(REG_LR_SYNC_WORD_LSB,  syncWord       & 0xFF);
}