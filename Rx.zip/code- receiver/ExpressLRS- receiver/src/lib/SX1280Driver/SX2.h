#ifndef INC_SX1280_H_
#define INC_SX1280_H_

#include "stm32f4xx_hal.h"
#include <stdint.h>

/* PIN DEFINITIONS */
#define SX_NSS_PORT     GPIOA
#define SX_NSS_PIN      GPIO_PIN_4
#define SX_BUSY_PORT    GPIOA
#define SX_BUSY_PIN     GPIO_PIN_8    /* PA8 on your RX hardware */
#define SX_RESET_PORT   GPIOB
#define SX_RESET_PIN    GPIO_PIN_1
#define SX_DIO1_PORT    GPIOB
#define SX_DIO1_PIN     GPIO_PIN_0

/* COMMAND OPCODES */
#define CMD_SET_STANDBY             0x80
#define CMD_SET_RX                  0x82
#define CMD_SET_TX                  0x83
#define CMD_SET_PACKET_TYPE         0x8A
#define CMD_SET_RF_FREQ             0x86
#define CMD_SET_MODULATION_PARAMS   0x8B
#define CMD_SET_PACKET_PARAMS       0x8C
#define CMD_WRITE_BUFFER            0x1A
#define CMD_READ_BUFFER             0x1B
#define CMD_Write_Register          0x18
#define CMD_SET_DIO_IRQ_PARAMS      0x8D
#define CMD_GET_IRQ_STATUS          0x15
#define CMD_CLEAR_IRQ_STATUS        0x97
#define CMD_GET_RX_BUFFER_STATUS    0x17
#define CMD_GET_PACKET_STATUS       0x1D
#define SX1280_SET_BUFFERBASEADDRESS  0x8F

/* IRQ MASKS */
#define IRQ_TX_DONE          0x0001
#define IRQ_RX_DONE          0x0002
#define IRQ_SyncWordValid    0x0004
#define IRQ_SyncWordError    0x0008
#define IRQ_Header_Valid     0x0010
#define IRQ_Header_Error     0x0020
#define IRQ_CRCerror         0x0040
#define IRQ_Timeout          0x4000
#define IRQ_PreambleDetected 0x8000

/* REGISTER ADDRESSES */
#define REG_LR_SYNC_WORD_MSB    0x0944
#define REG_LR_SYNC_WORD_LSB    0x0945

/* FUNCTION PROTOTYPES */
void SX1280_Init(void);
void SX1280_WriteCmd(uint8_t cmd, uint8_t* data, uint8_t len);
void SX1280_ReadCmd(uint8_t cmd, uint8_t* txData, uint8_t txLen,
                    uint8_t* rxData, uint8_t rxLen);
void SX1280_WaitBusy(void);
void SX1280_ClearIrqStatus(uint16_t irqMask);
uint16_t SX1280_GetIrqStatus(void);
void SX1280_SetStandby(void);
void SX1280_SetPacketType_LoRa(void);
void SX1280_SetRfFrequency(uint32_t freq_hz);
void SX1280_SetLoRaModulationParams(void);
void SX1280_SetLoRaPacketParams(void);
void SX1280_SetDioIrqParams(uint16_t irqMask, uint16_t dio1Mask,
                             uint16_t dio2Mask, uint16_t dio3Mask);
void SX1280_SetBufferBaseAddress(uint8_t txBaseAddress, uint8_t rxBaseAddress);
void SX1280_WriteRegister(uint16_t address, uint8_t value);
void SX1280_SetLoRaSyncWord(uint16_t syncWord);
void SX1280_SetRx(uint16_t timeout_ms);
void SX1280_GetPayload(uint8_t* buffer, uint8_t* size, uint8_t max_size);
void SX1280_GetPacketStatus(int8_t* rssi, int8_t* snr);

extern SPI_HandleTypeDef hspi1;

#endif /* INC_SX1280_H_ */