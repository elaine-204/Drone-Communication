/*
 * main.c - STM32F411RE SX1280 RC Receiver
 *
 * Receives LoRa packets from TX bridge.
 * Decodes 16 RC channels from 32-byte big-endian payload.
 * Outputs CRSF RC frame on USART1 PA9 at 420000 baud to FC.
 * Debug on USART2 PA2 at 115200 baud.
 *
 * Radio config - MUST match TX bridge exactly:
 *   Frequency : 2.400 GHz
 *   SF9, BW1600, CR4/5
 *   Preamble=12, explicit header, payload variable, CRC on, IQ standard
 *   Sync word : 0x1424
 */

//#include "main.h"
#include "SX2.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "boxes.h"

uint32_t hopFrequencies[] = {
    2402000000UL,
    2405000000UL,
    2408000000UL,
    2412000000UL
};

uint8_t hopSequence[] = {
    0,2,0,3,1,2,3,0,1,2
};

#define HOP_SEQUENCE_LENGTH (sizeof(hopSequence)/sizeof(hopSequence[0]))

uint8_t hopStep = 0;

#define HOP_INTERVAL 50
uint32_t lastHopTime = 0;

/* --- HAL Handles --- */
SPI_HandleTypeDef  hspi1;
UART_HandleTypeDef huart1;  /* CRSF output to FC: PA9, 420000 baud */
UART_HandleTypeDef huart2;  /* Debug:             PA2, 115200 baud */

/* --- State --- */
static uint32_t ChannelData[16];    /* channel values in microseconds */
static uint32_t rxPackets  = 0;
static uint32_t rxErrors   = 0;
static uint32_t crsfSent   = 0;
static int8_t   rxRssi     = 0;
static int8_t   rxSnr      = 0;
static uint32_t lastPktMs  = 0;
static uint8_t  linkUp     = 0;
static char     msgBuf[256];

/* --- Forward declarations --- */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART1_Init(void);
static void MX_USART2_Init(void);
void Error_Handler(void);

/* ============================================================
 * CRSF helpers
 * ============================================================ */

static uint8_t crsf_crc8(const uint8_t *data, uint8_t len)
{
    uint8_t crc = 0;
    for (uint8_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (uint8_t j = 0; j < 8; j++)
            crc = (crc & 0x80) ? (crc << 1) ^ 0xD5 : (crc << 1);
    }
    return crc;
}


/* microseconds -> 11-bit CRSF raw value */
static uint32_t us_to_crsf(uint32_t us)
{
    int32_t raw = ((int32_t)(us - 1500) * 8) / 5 + 992;
    if (raw < 172)  raw = 172;
    if (raw > 1811) raw = 1811;
    return (uint32_t)raw;
}

/* Pack 16 channels into 26-byte CRSF RC frame */
static void crsf_pack_channels(const uint32_t *ch, uint8_t *out)
{
    out[0] = 0xC8;  /* addr: to FC */
    out[1] = 0x18;  /* len: 24 bytes follow */
    out[2] = 0x16;  /* type: RC channels */

    uint8_t *p = &out[3];
    p[0]  = (uint8_t)( ch[0]         & 0xFF);
    p[1]  = (uint8_t)((ch[0] >>  8)  | (ch[1] << 3)) & 0xFF;
    p[2]  = (uint8_t)((ch[1] >>  5)  | (ch[2] << 6)) & 0xFF;
    p[3]  = (uint8_t)( ch[2] >>  2)  & 0xFF;
    p[4]  = (uint8_t)((ch[2] >> 10)  | (ch[3] << 1)) & 0xFF;
    p[5]  = (uint8_t)((ch[3] >>  7)  | (ch[4] << 4)) & 0xFF;
    p[6]  = (uint8_t)((ch[4] >>  4)  | (ch[5] << 7)) & 0xFF;
    p[7]  = (uint8_t)( ch[5] >>  1)  & 0xFF;
    p[8]  = (uint8_t)((ch[5] >>  9)  | (ch[6] << 2)) & 0xFF;
    p[9]  = (uint8_t)((ch[6] >>  6)  | (ch[7] << 5)) & 0xFF;
    p[10] = (uint8_t)( ch[7] >>  3)  & 0xFF;
    p[11] = (uint8_t)( ch[8]         & 0xFF);
    p[12] = (uint8_t)((ch[8] >>  8)  | (ch[9]  << 3)) & 0xFF;
    p[13] = (uint8_t)((ch[9] >>  5)  | (ch[10] << 6)) & 0xFF;
    p[14] = (uint8_t)( ch[10] >> 2)  & 0xFF;
    p[15] = (uint8_t)((ch[10] >> 10) | (ch[11] << 1)) & 0xFF;
    p[16] = (uint8_t)((ch[11] >>  7) | (ch[12] << 4)) & 0xFF;
    p[17] = (uint8_t)((ch[12] >>  4) | (ch[13] << 7)) & 0xFF;
    p[18] = (uint8_t)( ch[13] >> 1)  & 0xFF;
    p[19] = (uint8_t)((ch[13] >>  9) | (ch[14] << 2)) & 0xFF;
    p[20] = (uint8_t)((ch[14] >>  6) | (ch[15] << 5)) & 0xFF;
    p[21] = (uint8_t)( ch[15] >> 3)  & 0xFF;

    out[25] = crsf_crc8(&out[2], 23);
}

static void send_crsf(void)
{
    uint32_t raw[16];
    for (int i = 0; i < 16; i++) raw[i] = us_to_crsf(ChannelData[i]);
    uint8_t frame[26];
    crsf_pack_channels(raw, frame);
    HAL_UART_Transmit(&huart1, frame, 26, 5);
    crsfSent++;
}

// AES-128 decrypt
void KeyExpansionCore(unsigned char* in, unsigned char i)
{
	//Rotate Left
	unsigned int* q = (unsigned int*)in;
	*q = (*q >> 8) | ((*q & 0xff) << 24);

	//S-BOX 4Bytes
	in[0] = s_box[in[0]];
	in[1] = s_box[in[1]];
	in[2] = s_box[in[2]];
	in[3] = s_box[in[3]];

	//RCon
	in[0] ^= rcon[i];
}
void KeyExpansion(unsigned char* inputKey, unsigned char* expandedKeys)
{
	for (int i = 0; i < 16; i++)
		expandedKeys[i] = inputKey[i];

	int bytesGenerated = 16;
	int rconIteration = 1;
	unsigned char temp[4];

	while (bytesGenerated < 176)
	{
		for (int i = 0; i < 4; i++)
			temp[i] = expandedKeys[i + bytesGenerated - 4];

		if (bytesGenerated % 16 == 0)
		{
			KeyExpansionCore(temp, rconIteration);
			rconIteration++;
		}

		for (unsigned char a = 0; a < 4; a++)
		{
			expandedKeys[bytesGenerated]= expandedKeys[bytesGenerated - 16] ^ temp[a];
			bytesGenerated++;
		}
	}
}
void inv_sub_bytes(unsigned char* state) {
	// Substitute each state value with another byte in the Rijndael S-Box
	for (int i = 0; i < 16; i++)
		state[i] = inv_s_box[state[i]];
}
void inv_shift_rows(unsigned char* state) {
	unsigned char tmp[16];

	// First row don't shift (idx = idx)
	tmp[0] = state[0];
	tmp[4] = state[4];
	tmp[8] = state[8];
	tmp[12] = state[12];

	// Second row shift right once (idx = (idx - 4) % 16)
	tmp[1] = state[13];
	tmp[5] = state[1];
	tmp[9] = state[5];
	tmp[13] = state[9];

	// Third row shift right twice (idx = (idx +/- 8) % 16)
	tmp[2] = state[10];
	tmp[6] = state[14];
	tmp[10] = state[2];
	tmp[14] = state[6];

	// Fourth row shift right three times (idx = (idx + 4) % 16)
	tmp[3] = state[7];
	tmp[7] = state[11];
	tmp[11] = state[15];
	tmp[15] = state[3];

	for (int i = 0; i < 16; i++)
		state[i] = tmp[i];
}
void inv_mix_columns(unsigned char* state) {
	unsigned char tmp[16];

	// Column 1
	tmp[0] = (unsigned char)(mul14[state[0]] ^ mul11[state[1]] ^ mul13[state[2]] ^ mul9[state[3]]);
	tmp[1] = (unsigned char)(mul9[state[0]] ^ mul14[state[1]] ^ mul11[state[2]] ^ mul13[state[3]]);
	tmp[2] = (unsigned char)(mul13[state[0]] ^ mul9[state[1]] ^ mul14[state[2]] ^ mul11[state[3]]);
	tmp[3] = (unsigned char)(mul11[state[0]] ^ mul13[state[1]] ^ mul9[state[2]] ^ mul14[state[3]]);

	// Column 2
	tmp[4] = (unsigned char)(mul14[state[4]] ^ mul11[state[5]] ^ mul13[state[6]] ^ mul9[state[7]]);
	tmp[5] = (unsigned char)(mul9[state[4]] ^ mul14[state[5]] ^ mul11[state[6]] ^ mul13[state[7]]);
	tmp[6] = (unsigned char)(mul13[state[4]] ^ mul9[state[5]] ^ mul14[state[6]] ^ mul11[state[7]]);
	tmp[7] = (unsigned char)(mul11[state[4]] ^ mul13[state[5]] ^ mul9[state[6]] ^ mul14[state[7]]);

	// Column 3
	tmp[8] = (unsigned char)(mul14[state[8]] ^ mul11[state[9]] ^ mul13[state[10]] ^ mul9[state[11]]);
	tmp[9] = (unsigned char)(mul9[state[8]] ^ mul14[state[9]] ^ mul11[state[10]] ^ mul13[state[11]]);
	tmp[10] = (unsigned char)(mul13[state[8]] ^ mul9[state[9]] ^ mul14[state[10]] ^ mul11[state[11]]);
	tmp[11] = (unsigned char)(mul11[state[8]] ^ mul13[state[9]] ^ mul9[state[10]] ^ mul14[state[11]]);

	// Column 4
	tmp[12] = (unsigned char)(mul14[state[12]] ^ mul11[state[13]] ^ mul13[state[14]] ^ mul9[state[15]]);
	tmp[13] = (unsigned char)(mul9[state[12]] ^ mul14[state[13]] ^ mul11[state[14]] ^ mul13[state[15]]);
	tmp[14] = (unsigned char)(mul13[state[12]] ^ mul9[state[13]] ^ mul14[state[14]] ^ mul11[state[15]]);
	tmp[15] = (unsigned char)(mul11[state[12]] ^ mul13[state[13]] ^ mul9[state[14]] ^ mul14[state[15]]);

	for (int i = 0; i < 16; i++)
		state[i] = tmp[i];
}
void AddRoundKey(unsigned char* state, unsigned char* roundKey)
{
	for (int i = 0; i < 16; i++)
		state[i] ^= roundKey[i];
}

void aes_decrypt(unsigned char* message, unsigned char* key) {
	
	unsigned char state[16];
	for (int i = 0; i < 16; i++)
		state[i] = message[i];

	const int round_cnt = 9;
	unsigned char expandedKey[176];
	//Initial Round
	KeyExpansion(key, expandedKey);
	AddRoundKey(state, expandedKey + 160);

	for (int i = round_cnt; i > 0; i--) {
		inv_shift_rows(state);
		inv_sub_bytes(state);
		AddRoundKey(state, expandedKey + (16 * i));
		inv_mix_columns(state);
	}
	inv_shift_rows(state);
	inv_sub_bytes(state);
	AddRoundKey(state, expandedKey);

	for (int i = 0; i < 16; i++)
		message[i] = state[i];
}

/* ============================================================
 * Decode 32-byte big-endian payload -> microseconds
 * TX bridge packs: payload[i*2]<<8 | payload[i*2+1] = us value
 * ============================================================ */
static void decode_payload(const uint8_t *p, uint8_t len)
{
    if (len != 32) {
        // This fires if TX packet params payload length != 32
        sprintf(msgBuf, "bad len=%u (TX SetLoRaPacketParams buf[2] must be 32)\r\n", len);
        HAL_UART_Transmit(&huart2, (uint8_t*)msgBuf, strlen(msgBuf), 100);
        rxErrors++;
        return;
    }
    for (int i = 0; i < 16; i++) {
        uint16_t us = ((uint16_t)p[i*2] << 8) | p[i*2+1];
        if (us < 800)  us = 800;
        if (us > 2200) us = 2200;
        ChannelData[i] = us;
    }
}

static void apply_failsafe(void)
{
    for (int i = 0; i < 16; i++) ChannelData[i] = 1500;
    ChannelData[2] = 988; /* throttle minimum */
}

void Packet_Is_Error(void)
{

    sprintf(msgBuf, "timeouterr\n");
    HAL_UART_Transmit(&huart2, (uint8_t*)msgBuf, strlen(msgBuf), 100);
    rxErrors++;
}

/* ============================================================
 * main
 * ============================================================ */
unsigned char AES_Key[16] = {
0x50,0x41,0x53,0x53,
0x57,0x4F,0x52,0x44,
0x31,0x32,0x33,0x34,
0x35,0x36,0x37,0x38
};
// P A S S W O R D 1 2 3 4 5 6 7 8
int main(void)
{
    /* Init all channels to centre */
    for (int i = 0; i < 16; i++) ChannelData[i] = 1500;
    ChannelData[2] = 988;

    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_SPI1_Init();
    MX_USART1_Init();
    MX_USART2_Init();

    sprintf(msgBuf, "\r\n=== SX1280 RC Receiver ===\r\n");
    HAL_UART_Transmit(&huart2, (uint8_t*)msgBuf, strlen(msgBuf), 100);

    /* Hard reset */
    HAL_GPIO_WritePin(SX_RESET_PORT, SX_RESET_PIN, GPIO_PIN_RESET);
    HAL_Delay(50);
    HAL_GPIO_WritePin(SX_RESET_PORT, SX_RESET_PIN, GPIO_PIN_SET);
    HAL_Delay(50);

    HAL_GPIO_WritePin(SX_NSS_PORT, SX_NSS_PIN, GPIO_PIN_SET);
    HAL_Delay(5);

    /* Radio init sequence - matches working RX project exactly */
    SX1280_SetStandby();
    HAL_Delay(5);

    SX1280_SetPacketType_LoRa();
    HAL_Delay(5);

    SX1280_SetRfFrequency(hopFrequencies[0]);  /* 2.4 GHz - must match TX bridge */
    HAL_Delay(5);

    SX1280_SetLoRaSyncWord(0x1424);
    HAL_Delay(5);

    SX1280_SetBufferBaseAddress(0x00, 0x00);
    HAL_Delay(5);

    SX1280_SetLoRaModulationParams();  /* SF9, BW1600, CR4/5 */
    HAL_Delay(5);

    SX1280_SetLoRaPacketParams();      /* preamble=12, variable, CRC on */
    HAL_Delay(5);

    SX1280_SetDioIrqParams(0xFFFF, IRQ_RX_DONE, 0x0000, 0x0000);
    HAL_Delay(5);

    SX1280_SetRx(0);  /* continuous RX */
    HAL_Delay(5);

    sprintf(msgBuf, "Radio listening. 2.4GHz SF9 BW1600 sync=0x1424\r\n");
    HAL_UART_Transmit(&huart2, (uint8_t*)msgBuf, strlen(msgBuf), 100);

    uint32_t lastCrsfMs  = 0;
    uint32_t lastPrintMs = 0;

    while (1)
    {
        uint32_t now = HAL_GetTick();

if (now - lastHopTime >= HOP_INTERVAL) {
    lastHopTime = now;

    uint8_t channelIndex = hopSequence[hopStep];

    SX1280_SetRfFrequency(hopFrequencies[channelIndex]);

    hopStep = (hopStep + 1) % HOP_SEQUENCE_LENGTH;
}

        /* ── DIO1 HIGH = IRQ pending ─────────────────────────── */
        if (HAL_GPIO_ReadPin(SX_DIO1_PORT, SX_DIO1_PIN) == GPIO_PIN_SET)
        {
            uint16_t irq = SX1280_GetIrqStatus();

            if (irq & IRQ_RX_DONE)
            {
                SX1280_WaitBusy();

                uint8_t payload[255] = {0};
                uint8_t plen = 0;
                SX1280_GetPacketStatus(&rxRssi, &rxSnr);
                SX1280_GetPayload(payload, &plen, 255);

                if (plen == 32) {
                    aes_decrypt(payload,AES_Key);
                    decode_payload(payload, plen);
                    rxPackets++;
                    lastPktMs = now;
                    linkUp = 1;
                }

                else 
                {
                    rxErrors++;
                    sprintf(msgBuf, "bad len=%u\r\n", plen);
                    HAL_UART_Transmit(&huart2, (uint8_t*)msgBuf, strlen(msgBuf), 100);
                }
            }

            if (irq & IRQ_CRCerror)     
            {
                sprintf(msgBuf, "CRC error\r\n");
                HAL_UART_Transmit(&huart2, (uint8_t*)msgBuf, strlen(msgBuf), 100);
            }

            if (irq & IRQ_Header_Error) 
            {
                sprintf(msgBuf, "Header error\r\n");
                HAL_UART_Transmit(&huart2, (uint8_t*)msgBuf, strlen(msgBuf), 100);
            }

            if(irq & 0x0008)
            {
            	sprintf(msgBuf, "syncerror ");
            	HAL_UART_Transmit(&huart2, (uint8_t*)msgBuf, strlen(msgBuf), 100);
            	SX1280_ClearIrqStatus(0x0008);
            }

            if(irq & 0x4000)
            {
                Packet_Is_Error();
                SX1280_ClearIrqStatus(0x4000);
            }
            if(irq & 0x0004)
            	{
            		sprintf(msgBuf, "syncwordvalid ");
            		HAL_UART_Transmit(&huart2, (uint8_t*)msgBuf, strlen(msgBuf), 100);
            		SX1280_ClearIrqStatus(0x0004);
            	}

            /* Clear all IRQs and restart continuous RX */
            SX1280_ClearIrqStatus(0xFFFF);
            SX1280_SetRx(0);
        }

        /* ── Failsafe after 1 second silence ────────────────── */
        if (linkUp && (now - lastPktMs > 2000)) {
            linkUp = 0;
            apply_failsafe();
            sprintf(msgBuf, "*** FAILSAFE ***\r\n");
            HAL_UART_Transmit(&huart2, (uint8_t*)msgBuf, strlen(msgBuf), 100);
        }

        if (now - lastCrsfMs >= 100) {
            lastCrsfMs = now;
            send_crsf();
        }

        if (now - lastPrintMs >= 100) {
            lastPrintMs = now;
            if (!linkUp) {
                sprintf(msgBuf, "NO LINK | pkts=%lu err=%lu | DIO1=%s BUSY=%s\r\n",
                    rxPackets, rxErrors,
                    HAL_GPIO_ReadPin(SX_DIO1_PORT, SX_DIO1_PIN)==GPIO_PIN_SET ? "HI":"LO",
                    HAL_GPIO_ReadPin(SX_BUSY_PORT, SX_BUSY_PIN)==GPIO_PIN_SET ? "HI":"LO");
            } else {
                sprintf(msgBuf,
                    "LINK OK | RSSI=%ddBm SNR=%ddB | pkts=%lu err=%lu | "
                    "CH1:%lu CH2:%lu CH3:%lu CH4:%lu | crsf=%lu\r\n",
                    rxRssi, rxSnr, rxPackets, rxErrors,
                    ChannelData[0], ChannelData[1], ChannelData[2], ChannelData[3],
                    crsfSent);
            }
            HAL_UART_Transmit(&huart2, (uint8_t*)msgBuf, strlen(msgBuf), 100);
        }
    }
}


void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    RCC_OscInitStruct.OscillatorType      = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState            = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState        = RCC_PLL_NONE;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

    RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                     | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_HSI;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();


      /*Configure GPIO pin Output Level */
    //HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
    //HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET);


    /* PA4 NSS - output, start HIGH */
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
    GPIO_InitStruct.Pin   = GPIO_PIN_4;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* PA8 BUSY - input with pulldown */
    GPIO_InitStruct.Pin  = GPIO_PIN_8;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLDOWN;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* PB0 DIO1 - input */
    GPIO_InitStruct.Pin  = GPIO_PIN_0;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* PB1 RESET - output, start HIGH */
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET);
    GPIO_InitStruct.Pin   = GPIO_PIN_1;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

static void MX_SPI1_Init(void)
{
    /* SPI pins: PA5=SCK PA6=MISO PA7=MOSI */
    __HAL_RCC_SPI1_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin       = GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF5_SPI1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* Mode 0: POLARITY_LOW + PHASE_1EDGE - matches working RX */
    hspi1.Instance               = SPI1;
    hspi1.Init.Mode              = SPI_MODE_MASTER;
    hspi1.Init.Direction         = SPI_DIRECTION_2LINES;
    hspi1.Init.DataSize          = SPI_DATASIZE_8BIT;
    hspi1.Init.CLKPolarity       = SPI_POLARITY_LOW;
    hspi1.Init.CLKPhase          = SPI_PHASE_1EDGE;
    hspi1.Init.NSS               = SPI_NSS_SOFT;
    hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_32;
    hspi1.Init.FirstBit          = SPI_FIRSTBIT_MSB;
    hspi1.Init.TIMode            = SPI_TIMODE_DISABLE;
    hspi1.Init.CRCCalculation    = SPI_CRCCALCULATION_DISABLE;
    hspi1.Init.CRCPolynomial     = 10;
    if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USART1 PA9=TX - CRSF output to flight controller at 420000 baud */
static void MX_USART1_Init(void)
{
    __HAL_RCC_USART1_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin       = GPIO_PIN_9;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    huart1.Instance          = USART1;
    huart1.Init.BaudRate     = 420000;
    huart1.Init.WordLength   = UART_WORDLENGTH_8B;
    huart1.Init.StopBits     = UART_STOPBITS_1;
    huart1.Init.Parity       = UART_PARITY_NONE;
    huart1.Init.Mode         = UART_MODE_TX;
    huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart1.Init.OverSampling = UART_OVERSAMPLING_16;
    HAL_UART_Init(&huart1);
}

/* USART2 PA2=TX PA3=RX - debug at 115200 baud */
static void MX_USART2_Init(void)
{
    __HAL_RCC_USART2_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin       = GPIO_PIN_2 | GPIO_PIN_3;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    huart2.Instance          = USART2;
    huart2.Init.BaudRate     = 115200;
    huart2.Init.WordLength   = UART_WORDLENGTH_8B;
    huart2.Init.StopBits     = UART_STOPBITS_1;
    huart2.Init.Parity       = UART_PARITY_NONE;
    huart2.Init.Mode         = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) {}
}